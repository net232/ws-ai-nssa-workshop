# 원인 분석(RCA) 예시: Lab 4 장애

> 구조를 보여 주는 예시입니다. 참석자 산출물 위치: `~/ws-lab/rca.md`. 증거 칸에는 **실제로 실행한 명령과 출력**만 붙입니다.

## 1. 증상

- 언제: <UTC 시각>
- 무엇: `test-matrix.sh PHASE=base`에서 T1(client-valid)이 REJECT, T3(client-other-ca)이 ACCEPT. :8443 대조군은 정상.
- 재현 명령(실패하는 명령 하나):

```bash
curl -sS --cacert certs/lab-root-ca.pem --cert certs/client-valid.pem --key certs/client-valid.key \
  --connect-to mtls.lab.internal:443:$NLB_DNS:443 https://mtls.lab.internal/
```

## 2. 범위 좁히기

| 관찰 | 의미 |
|---|---|
| :8443(mTLS off)은 정상 | 네트워크·대상·서버 인증서는 정상 → mTLS 검사 단계 문제 |
| 정상 인증서는 거부, 다른 CA 인증서는 통과 | trust store가 신뢰하는 CA가 바뀌었을 가능성 |

## 3. 가설과 증거

| 가설 | 확인 명령 | 결과 | 판정 |
|---|---|---|---|
| H1 CRL에 정상 인증서가 들어감 | `aws elbv2 describe-trust-store-revocations --region ap-northeast-2 --trust-store-arn ...` | <출력> | 기각/채택 |
| H2 CA 번들이 바뀜 | `get-trust-store-ca-certificates-bundle`로 받은 번들과 `certs/ca-bundle.pem`의 `openssl x509 -noout -subject -fingerprint -sha256` 비교, `describe-trust-stores`의 `NumberOfCaCertificates` | <출력> | |
| H3 필터 설정 변경 | `aws elbv2 describe-listeners --region ap-northeast-2 ... --query 'Listeners[0].MutualAuthentication'` | <출력> | |
| access log | `scripts/fetch-logs.sh 15` | <T1 실행 시각·포트 443 행의 tls_verify_status. 거부 행은 subject·serial이 `-`라 시각으로 찾음. 리허설 값: `Failed:ClientCertUntrusted`> | |

## 4. 근본 원인

<한 문장. 예: trust store의 CA 번들이 rogue CA 번들로 교체되어 lab CA가 서명한 인증서가 ClientCertUntrusted로 거부됨>

## 5. 조치와 재확인

- 조치 명령: <...>
- 재확인: 같은 재현 명령 → HTTP 200, `test-matrix.sh` PASS <n>/<n>

## 6. 재발 방지

- CA 번들 교체는 CloudFormation으로만 하고, 교체 전후에 번들 인증서의 subject·SHA-256 fingerprint를 기준 값과 비교하는 단계를 체크리스트에 추가
  (TrustStore의 CA 번들 S3 속성은 writeOnly일 수 있어 `detect-stack-drift`가 이 변경을 잡는다고 가정하지 않음)
- 기준 fingerprint를 저장해 두고 주기적으로 비교(예: 스케줄된 스크립트)
