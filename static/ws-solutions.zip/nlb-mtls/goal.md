# 목표: NLB mutual TLS 테스트

> Lab 1 2단계 정답 예시. `/grill-me`로 결정한 내용을 정리한 것입니다. 참석자 산출물 위치는 `~/ws-lab/goal.md`입니다.

## 목적

- **누구에게**: 고객 데모(mTLS를 앱 서버가 아니라 NLB에서 처리하려는 고객)와 사내 워크숍 참석자
- **무엇을 보여 주나**: 클라이언트 인증서 종류에 따라 NLB가 허용하거나 거부하는 모습, 그리고 거부 사유가 access log에 남는 모습

## 범위

- 포함: TLS 리스너의 mTLS verify 모드, trust store(CA 번들 + CRL), identity filter, access log의 mTLS 필드, mTLS off 리스너와의 비교
- 제외: AWS Private CA 연동, RAM으로 trust store 공유, AWS Load Balancer Controller, 성능 측정

## 성공 기준

- 테스트 계획서의 모든 케이스가 기대 결과와 일치하고, 케이스마다 명령 출력이나 로그 줄로 된 증적이 있다.
- 거부 케이스마다 access log의 `tls_verify_status` 사유 코드를 확인한다.
- 문서끼리 다른 곳은 실제 동작으로 어느 쪽이 맞는지 확인하거나, 확인하지 못했다고 적는다.

## 시간과 비용

- 시간: 워크숍 Lab 1–4 안(약 3시간). 배포는 5분 안팎, 설정 변경은 반영되는 데 1–3분 걸린다.
- 비용: NAT gateway, NLB, EC2 3대(t4g.micro)가 몇 시간 떠 있는 정도(약 $1 이하). 끝나면 바로 정리한다.
