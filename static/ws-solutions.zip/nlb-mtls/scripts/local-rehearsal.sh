#!/usr/bin/env bash
# local-rehearsal.sh — AWS에 배포하기 전에 openssl s_server로 인증서 매트릭스를 로컬에서 미리 돌려 봅니다.
# trust chain / CRL / EKU / 만료 검사는 openssl이 흉내 내지만, NLB 전용 동작
# (client certificate identity filter, access log 코드)은 재현하지 않습니다.
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/lib.sh
cd "$CERT_DIR"
cat ca-bundle.pem crl.pem > /tmp/ca-crl.pem
openssl s_server -quiet -accept 18443 -www -cert server.pem -key server.key \
  -CAfile /tmp/ca-crl.pem -Verify 2 -verify_return_error -crl_check -purpose sslclient \
  </dev/null >/dev/null 2>&1 & P1=$!
openssl s_server -quiet -accept 18444 -www -cert server.pem -key server.key \
  </dev/null >/dev/null 2>&1 & P2=$!
trap 'kill $P1 $P2 2>/dev/null || true' EXIT
sleep 1
NLB_DNS=127.0.0.1 CERTS="$CERT_DIR" MTLS_PORT=18443 PLAIN_PORT=18444 \
  bash "$LAB_DIR/scripts/test-matrix.sh"
