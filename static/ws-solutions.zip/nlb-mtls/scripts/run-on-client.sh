#!/usr/bin/env bash
# run-on-client.sh — 로컬 스크립트를 SSM Run Command로 클라이언트 EC2에서 실행하고 출력을 돌려받습니다.
# Claude Code가 직접 테스트를 돌릴 수 있게 해 줍니다(대화형 세션 없이).
#   사용법: scripts/run-on-client.sh scripts/test-matrix.sh [VAR=value ...]
#   예:     scripts/run-on-client.sh scripts/test-matrix.sh PHASE=filter
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/lib.sh

SCRIPT="${1:?실행할 스크립트 경로}"; shift
ENVS=""
(( $# )) && ENVS="$(printf '%q ' "$@")"   # 값에 공백이 있어도 원격에서 한 인자로 유지(인자가 없으면 빈 문자열)
IID="$(stack_output ClientInstanceId)"
B64="$(base64 < "$SCRIPT" | tr -d '\n')"
CMD="source /etc/profile.d/lab.sh; echo $B64 | base64 -d > /tmp/run.sh; env $ENVS bash /tmp/run.sh"

CID="$(aws ssm send-command --region "$R" --instance-ids "$IID" \
  --document-name AWS-RunShellScript --comment "ws-ai-nssa $(basename "$SCRIPT")" \
  --parameters "$(jq -cn --arg c "$CMD" '{commands:[$c]}')" \
  --query Command.CommandId --output text)"
log "SSM command $CID → $IID"

TIMEOUT="${TIMEOUT:-120}"   # 초
ST=Pending; waited=0
while [[ "$ST" == Pending || "$ST" == InProgress || "$ST" == Delayed ]]; do
  if (( waited >= TIMEOUT )); then
    log "시간 초과(${TIMEOUT}s): command $CID 상태 $ST"; exit 124
  fi
  sleep 3; waited=$((waited+3))
  ST="$(aws ssm get-command-invocation --region "$R" --command-id "$CID" --instance-id "$IID" \
        --query Status --output text 2>/dev/null || echo Pending)"
done

INV="$(aws ssm get-command-invocation --region "$R" --command-id "$CID" --instance-id "$IID" --output json)"
jq -r '.StandardOutputContent' <<<"$INV"
ERR="$(jq -r '.StandardErrorContent // ""' <<<"$INV")"
[[ -n "$ERR" ]] && { echo "--- stderr ---"; echo "$ERR"; }
RC="$(jq -r '.ResponseCode' <<<"$INV")"
log "Status: $ST, ResponseCode: $RC"
# 원격 스크립트의 종료 코드를 그대로 돌려줍니다(Success가 아니면 0이 아님).
if [[ "$ST" != Success ]]; then
  [[ "$RC" =~ ^[0-9]+$ && "$RC" -ne 0 ]] && exit "$RC"
  exit 1
fi
exit 0
