#!/usr/bin/env bash
# cleanup.sh — Track A(NLB mTLS)에서 만든 리소스를 모두 지웁니다.
#   1) 로그 버킷 비우기 (비어 있지 않으면 스택 삭제가 실패)
#   2) CloudFormation 스택 삭제 (VPC, NAT GW, NLB, trust store, EC2 ...)
#   3) ACM에 import한 서버 인증서 삭제
#   4) artifact 버킷(trust store 파일, 클라이언트 키) 비우고 삭제
#   5) 로컬 개인 키 삭제 여부 확인
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/lib.sh

# Show which account and Region this will delete from; FORCE=1 skips the question.
ACCT="$(aws sts get-caller-identity --region "$R" --query Account --output text)"
echo "계정 $ACCT 의 ws-ai-nssa-nlb-mtls 리소스를 삭제합니다 (리전: $R)."
if [[ "${FORCE:-0}" != 1 ]]; then
  read -r -p "맞으면 yes 를 입력하세요: " ok
  [[ "$ok" == yes ]] || { echo "중단했습니다."; exit 1; }
fi

empty_logs() { aws s3 rm --region "$R" --recursive --only-show-errors "s3://$1" || true; }

if aws cloudformation describe-stacks --region "$R" --stack-name "$STACK" >/dev/null 2>&1; then
  LOGS="$(stack_output LogsBucketName)"
  NLB="$(stack_output NlbArn)"
  if [[ -n "$NLB" && "$NLB" != None ]]; then
    log "access log 전달 끄기 (비운 뒤 새 로그가 들어와 버킷 삭제가 실패하지 않도록)"
    aws elbv2 modify-load-balancer-attributes --region "$R" --load-balancer-arn "$NLB" \
      --attributes Key=access_logs.s3.enabled,Value=false >/dev/null || true
  fi
  for attempt in 1 2 3; do
    if [[ -n "$LOGS" && "$LOGS" != None ]]; then
      log "로그 버킷 비우기: $LOGS (시도 $attempt)"
      empty_logs "$LOGS"
    fi
    log "스택 삭제: $STACK (시도 $attempt)"
    aws cloudformation delete-stack --region "$R" --stack-name "$STACK"
    if aws cloudformation wait stack-delete-complete --region "$R" --stack-name "$STACK"; then
      break
    fi
    [[ $attempt -eq 3 ]] && { echo "스택 삭제 실패. CloudFormation 이벤트를 확인하세요." >&2; exit 1; }
    log "삭제 실패(DELETE_FAILED). 남은 로그를 비우고 다시 시도합니다."
  done
fi

CERT_ARN="$(state_get server_cert_arn)"
if [[ -n "$CERT_ARN" ]]; then
  log "ACM 인증서 삭제: $CERT_ARN"
  if OUT="$(aws acm delete-certificate --region "$R" --certificate-arn "$CERT_ARN" 2>&1)" \
     || grep -q ResourceNotFoundException <<<"$OUT"; then
    state_set server_cert_arn ""
  else
    echo "$OUT" >&2
    echo "ACM 인증서를 지우지 못했습니다(아직 리스너가 쓰고 있을 수 있음). 잠시 뒤 cleanup.sh를 다시 실행하세요." >&2
  fi
fi

BUCKET="$(artifact_bucket)"
if aws s3api head-bucket --region "$R" --bucket "$BUCKET" >/dev/null 2>&1; then
  log "artifact 버킷 삭제: $BUCKET"
  aws s3 rb --region "$R" --force "s3://$BUCKET"
fi

log "남은 리소스 확인 (Project=ws-ai-nssa 태그, $R). Workshop IDE 스택(ws-ai-nssa-ide)은 90-cleanup에서 지우므로 제외합니다."
LEFT="$(aws resourcegroupstaggingapi get-resources --region "$R" --tag-filters Key=Project,Values=ws-ai-nssa --output json \
  | jq -r '.ResourceTagMappingList[]
      | select(([.Tags[] | select(.Key == "aws:cloudformation:stack-name") | .Value] | index("ws-ai-nssa-ide")) | not)
      | select(.ResourceARN | test(":stack/ws-ai-nssa-ide/") | not)
      | .ResourceARN')"
if [[ -n "$LEFT" ]]; then
  echo "$LEFT"
  echo "위 리소스가 남아 있습니다. 태그 API는 삭제 직후 몇 분 동안 지운 리소스를 보여 줄 수 있으니, 잠시 뒤 다시 확인하세요." >&2
else
  log "남은 리소스 없음"
fi

read -r -p "로컬 인증서·개인 키 폴더($CERT_DIR)도 지울까요? [y/N] " a
[[ "$a" == y || "$a" == Y ]] && rm -rf "$CERT_DIR" && log "삭제했습니다."
