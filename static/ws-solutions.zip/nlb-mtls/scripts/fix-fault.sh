#!/usr/bin/env bash
# fix-fault.sh — Lab 4 정답지. inject-fault.sh 가 주입한 장애를 되돌립니다.
# 실습에서는 먼저 Claude Code와 함께 원인을 찾고 직접 고친 뒤, 확인용으로만 쓰세요.
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/lib.sh

N="${1:-$(state_get fault)}"
[[ -n "$N" ]] || { echo "주입된 장애 기록이 없습니다."; exit 0; }
BUCKET="$(artifact_bucket)"
TS="$(stack_output TrustStoreArn)"

case "$N" in
  1)
    TSG="$(stack_output TargetSecurityGroupId)"; NSG="$(stack_output NlbSecurityGroupId)"
    aws ec2 authorize-security-group-ingress --region "$R" --group-id "$TSG" \
      --ip-permissions "IpProtocol=tcp,FromPort=8080,ToPort=8080,UserIdGroupPairs=[{GroupId=$NSG,Description=traffic and health checks from NLB}]" >/dev/null
    echo "원인: target SG에서 NLB SG → TCP 8080 인바운드가 빠짐 → 대상 Unhealthy, mTLS는 Success인데 연결 실패" ;;
  2)
    aws elbv2 modify-trust-store --region "$R" --trust-store-arn "$TS" \
      --ca-certificates-bundle-s3-bucket "$BUCKET" --ca-certificates-bundle-s3-key truststore/ca-bundle.pem >/dev/null
    echo "원인: trust store CA 번들이 rogue CA로 교체됨 → 정상 클라이언트 ClientCertUntrusted, other-ca가 통과" ;;
  3)
    RID="$(state_get fault3_revocation_id)"
    aws elbv2 remove-trust-store-revocations --region "$R" --trust-store-arn "$TS" --revocation-ids "$RID"
    echo "원인: 정상 인증서를 폐기한 CRL(revocation id $RID)이 추가됨 → ClientCertCrlHit" ;;
  4)
    scripts/apply-filters.sh on >/dev/null
    echo "원인: 필터 값 오타(OU 'Prod')와 san-uri 경로 대소문자('/NS/') → CertificateFilterNoMatch"
    echo "      (주의: 실습 단계에 따라 필터가 원래 꺼져 있었다면 scripts/apply-filters.sh off)" ;;
esac
state_set fault ""
log "복구 명령 완료. 반영까지 1–3분 걸립니다(장애 1은 즉시). 그 뒤 test-matrix 로 다시 확인하세요."
