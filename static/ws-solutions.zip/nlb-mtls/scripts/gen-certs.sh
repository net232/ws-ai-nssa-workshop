#!/usr/bin/env bash
# gen-certs.sh — NLB mTLS 테스트 매트릭스용 인증서 일체를 만듭니다.
#
#   lab-root-ca      : trust store에 올릴 CA (ca-bundle.pem)
#   rogue-ca         : trust store에 없는 다른 CA
#   server           : NLB TLS 리스너 서버 인증서 (ACM import)
#   client-*         : 테스트 매트릭스의 클라이언트 인증서
#   crl.pem          : client-revoked 를 폐기한 CRL (PEM)
#
# 사용법: OUT_DIR=./certs ./gen-certs.sh
# 출력 폴더에는 개인 키가 들어 있습니다. git에 커밋하지 마세요.
set -euo pipefail

OUT_DIR="${OUT_DIR:-./certs}"
DOMAIN="${DOMAIN:-lab.internal}"
SERVER_NAME="${SERVER_NAME:-mtls.${DOMAIN}}"
DAYS="${DAYS:-30}"

# 안전장치: 기존 폴더는 FORCE=1일 때만 지우고, 위험한 경로는 거부합니다.
OUT_ABS="$(mkdir -p "$(dirname "${OUT_DIR}")" && cd "$(dirname "${OUT_DIR}")" && pwd -P)/$(basename "${OUT_DIR}")"
OUT_ABS="$(printf %s "${OUT_ABS}" | tr -s /)"
case "${OUT_ABS%/}" in
  ""|/|/root|/home|/tmp|/etc|/usr|/var|/opt|"${HOME%/}"|"${HOME%/}/ws-lab"|"$(pwd -P)")
    echo "OUT_DIR=${OUT_DIR} (${OUT_ABS}) 는 인증서 전용 폴더가 아닙니다. 예: OUT_DIR=~/ws-lab/certs" >&2; exit 1 ;;
esac
if [[ -e "${OUT_ABS}" ]]; then
  if [[ "${FORCE:-0}" != "1" ]]; then
    echo "${OUT_ABS} 가 이미 있습니다. 지우고 다시 만들려면 FORCE=1 을 주세요." >&2
    exit 1
  fi
  [[ -d "${OUT_ABS}/ca-lab-root-ca" || -z "$(ls -A "${OUT_ABS}")" ]] || {
    echo "${OUT_ABS} 는 gen-certs.sh가 만든 폴더가 아닌 것 같습니다(ca-lab-root-ca 없음). 직접 확인하세요." >&2; exit 1; }
  rm -rf "${OUT_ABS}"
fi
OUT_DIR="${OUT_ABS}"
mkdir -p "${OUT_DIR}"
cd "${OUT_DIR}"
umask 077

# ---------- openssl ca 설정 (CA마다 데이터베이스가 따로 필요: CRL, 과거 날짜 발급) ----------
make_ca_dir() {
  local name="$1" serial="$2"
  mkdir -p "ca-${name}/newcerts"
  : > "ca-${name}/index.txt"
  echo "${serial}" > "ca-${name}/serial"   # 양수 serial (NLB는 음수 serial 폐기를 무시함)
  echo "1000" > "ca-${name}/crlnumber"
  cat > "ca-${name}/openssl.cnf" <<EOF
[ ca ]
default_ca = CA_default
[ CA_default ]
dir               = ./ca-${name}
database          = \$dir/index.txt
new_certs_dir     = \$dir/newcerts
serial            = \$dir/serial
crlnumber         = \$dir/crlnumber
certificate       = ./${name}.pem
private_key       = ./${name}.key
default_md        = sha256
default_days      = ${DAYS}
default_crl_days  = ${DAYS}
policy            = policy_any
unique_subject    = no
copy_extensions   = none
[ policy_any ]
organizationName       = optional
organizationalUnitName = optional
commonName             = supplied
[ v3_ca ]
basicConstraints       = critical, CA:true
keyUsage               = critical, keyCertSign, cRLSign
subjectKeyIdentifier   = hash
[ server ]
basicConstraints       = CA:false
keyUsage               = critical, digitalSignature, keyEncipherment
extendedKeyUsage       = serverAuth
subjectAltName         = DNS:${SERVER_NAME}
[ client ]
basicConstraints       = CA:false
keyUsage               = critical, digitalSignature
extendedKeyUsage       = clientAuth
subjectAltName         = \${ENV::CLIENT_SAN}
[ client_eku_server ]
basicConstraints       = CA:false
keyUsage               = critical, digitalSignature
extendedKeyUsage       = serverAuth
subjectAltName         = \${ENV::CLIENT_SAN}
[ client_no_eku ]
basicConstraints       = CA:false
subjectAltName         = \${ENV::CLIENT_SAN}
EOF
}

make_root() {
  local name="$1" cn="$2"
  openssl req -x509 -new -nodes -newkey rsa:2048 -sha256 -days 365 \
    -keyout "${name}.key" -out "${name}.pem" \
    -subj "/O=ws-ai-nssa/CN=${cn}" \
    -addext "basicConstraints=critical,CA:true" \
    -addext "keyUsage=critical,keyCertSign,cRLSign" 2>/dev/null
}

# issue <ca> <name> <subject> <extension-section> <san> [startdate enddate]
issue() {
  local ca="$1" name="$2" subj="$3" ext="$4" san="$5" start="${6:-}" end="${7:-}"
  openssl req -new -nodes -newkey rsa:2048 -keyout "${name}.key" -out "${name}.csr" -subj "${subj}" 2>/dev/null
  local dates=()
  if [[ -n "${start}" ]]; then dates=(-startdate "${start}" -enddate "${end}"); fi
  CLIENT_SAN="${san}" openssl ca -batch -notext -config "ca-${ca}/openssl.cnf" \
    -extensions "${ext}" -in "${name}.csr" -out "${name}.pem" "${dates[@]}" 2>/dev/null
  rm -f "${name}.csr"
}

echo "[1/5] CA 두 개 (lab-root-ca, rogue-ca)"
make_root lab-root-ca "ws-ai-nssa lab root CA"
make_root rogue-ca   "ws-ai-nssa rogue CA"
make_ca_dir lab-root-ca 1000
make_ca_dir rogue-ca   5000
export CLIENT_SAN="DNS:unused.${DOMAIN}"   # [client*] 섹션이 ENV를 참조하므로 기본값

echo "[2/5] 서버 인증서 (${SERVER_NAME})"
issue lab-root-ca server "/O=ws-ai-nssa/CN=${SERVER_NAME}" server "DNS:${SERVER_NAME}"

echo "[3/5] 클라이언트 인증서"
issue lab-root-ca client-valid    "/O=ws-ai-nssa/OU=Production/CN=client-valid.${DOMAIN}" client \
  "DNS:client-valid.${DOMAIN},URI:spiffe://${DOMAIN}/ns/prod/sa/orders"
issue lab-root-ca client-staging  "/O=ws-ai-nssa/OU=Staging/CN=client-staging.${DOMAIN}" client \
  "DNS:client-staging.${DOMAIN},URI:spiffe://${DOMAIN}/ns/stg/sa/orders"
issue lab-root-ca client-uri-only "/O=ws-ai-nssa/OU=Engineering/CN=client-uri-only.${DOMAIN}" client \
  "DNS:client-uri-only.${DOMAIN},URI:spiffe://${DOMAIN}/ns/prod/sa/payments"
issue lab-root-ca client-revoked  "/O=ws-ai-nssa/OU=Production/CN=client-revoked.${DOMAIN}" client \
  "DNS:client-revoked.${DOMAIN}"
issue lab-root-ca client-eku-server "/O=ws-ai-nssa/OU=Production/CN=client-eku-server.${DOMAIN}" client_eku_server \
  "DNS:client-eku-server.${DOMAIN}"
issue lab-root-ca client-no-eku   "/O=ws-ai-nssa/OU=Production/CN=client-no-eku.${DOMAIN}" client_no_eku \
  "DNS:client-no-eku.${DOMAIN}"
# 만료: 과거 기간으로 발급
issue lab-root-ca client-expired  "/O=ws-ai-nssa/OU=Production/CN=client-expired.${DOMAIN}" client \
  "DNS:client-expired.${DOMAIN}" 20250101000000Z 20250201000000Z
issue rogue-ca    client-other-ca "/O=ws-ai-nssa/OU=Production/CN=client-other-ca.${DOMAIN}" client \
  "DNS:client-other-ca.${DOMAIN}"

echo "[4/5] CRL (client-revoked 폐기)"
openssl ca -config ca-lab-root-ca/openssl.cnf -revoke client-revoked.pem -crl_reason keyCompromise 2>/dev/null
openssl ca -config ca-lab-root-ca/openssl.cnf -gencrl -out crl.pem 2>/dev/null

echo "[5/5] 업로드용 파일"
# trust store CA 번들: PEM 블록만, 빈 줄·텍스트 없음 (NLB CA 파일 요구 사항)
cp lab-root-ca.pem ca-bundle.pem
cp rogue-ca.pem   ca-bundle-wrong.pem      # Lab 4 장애 주입용
cp lab-root-ca.pem server-chain.pem        # ACM import --certificate-chain

cat <<EOF

완료: $(pwd)
  trust store : ca-bundle.pem, crl.pem
  ACM import  : server.pem, server.key, server-chain.pem
  클라이언트  : client-valid, client-staging, client-uri-only, client-revoked, client-eku-server,
                client-no-eku, client-expired, client-other-ca  (*.pem / *.key)
EOF
