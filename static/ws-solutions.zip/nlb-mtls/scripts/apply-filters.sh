#!/usr/bin/env bash
# apply-filters.sh — 443 리스너에 client certificate identity filter를 적용/해제합니다.
#   필터: subject-ou exact "Production"  OR  san-uri prefix "spiffe://lab.internal/ns/prod/"
#   사용법: scripts/apply-filters.sh on | off | show
# CloudFormation 대신 CLI를 쓰는 이유: README "필터를 템플릿에 넣지 않은 이유" 참고.
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/lib.sh

L="$(stack_output MtlsListenerArn)"; TS="$(stack_output TrustStoreArn)"
case "${1:-show}" in
  on)
    aws elbv2 modify-listener --region "$R" --listener-arn "$L" --mutual-authentication "$(cat <<JSON
{"Mode":"verify","TrustStoreArn":"$TS","ClientCertificateIdentityFilters":[
  {"Field":"subject-ou","Action":"accept","MatchType":"exact","Value":"Production"},
  {"Field":"san-uri","Action":"accept","MatchType":"prefix","Value":"spiffe://lab.internal/ns/prod/"}]}
JSON
)" --query 'Listeners[0].MutualAuthentication' ;;
  off)
    aws elbv2 modify-listener --region "$R" --listener-arn "$L" \
      --mutual-authentication "{\"Mode\":\"verify\",\"TrustStoreArn\":\"$TS\",\"ClientCertificateIdentityFilters\":[]}" \
      --query 'Listeners[0].MutualAuthentication' ;;
  show)
    aws elbv2 describe-listeners --region "$R" --listener-arns "$L" --query 'Listeners[0].MutualAuthentication' ;;
  *) echo "on | off | show" >&2; exit 2 ;;
esac
# 리허설(2026-11-26): API는 바로 새 값을 돌려주지만 NLB 노드에 반영되기까지 1–2.5분 걸렸습니다.
[[ "${1:-show}" != show ]] && log "적용 요청 완료. 데이터 경로 반영까지 1–3분 걸립니다. 3분 뒤 test-matrix를 실행하세요." >&2
exit 0
