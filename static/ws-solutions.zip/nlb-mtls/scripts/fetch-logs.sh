#!/usr/bin/env bash
# fetch-logs.sh — NLB access log(5분마다 전달)를 내려받아 mTLS 관련 필드만 뽑습니다.
#   출력: time | port | client | tls_verify_status | leaf_client_cert_subject | serial
#   거부된 연결은 subject·serial이 "-"로 남습니다(리허설 확인). 케이스와는 시각·포트·순서로 짝짓습니다.
#   사용법: scripts/fetch-logs.sh [최근 N분, 기본 30]
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/lib.sh

MIN="${1:-30}"
BUCKET="$(stack_output LogsBucketName)"
OUT="$LAB_DIR/logs"; mkdir -p "$OUT"
aws s3 sync --region "$R" --only-show-errors "s3://$BUCKET/nlb/AWSLogs/" "$OUT/raw/"
SINCE="$(python3 -c "import datetime,sys;print((datetime.datetime.now(datetime.timezone.utc)-datetime.timedelta(minutes=int(sys.argv[1]))).strftime('%Y-%m-%dT%H:%M:%S'))" "$MIN")"
# 필드는 공백 구분이지만 subject는 따옴표로 묶여 있으므로 python으로 shlex 분해
find "$OUT/raw" -name '*.log.gz' -print0 | xargs -0 -r zcat | python3 -c '
import sys, shlex
since = sys.argv[1]
print("| time | port | client | tls_verify_status | leaf_client_cert_subject | serial |")
print("|---|---|---|---|---|---|")
rows = []
for line in sys.stdin:
    f = shlex.split(line)
    if len(f) < 26 or f[2] < since: continue
    # 0 type 1 version 2 time 3 elb 4 listener 5 client:port 6 destination:port ... 21 tls_connection_creation_time 22 tls_verify_status 23 subject 24 validity 25 serial
    rows.append((f[2], f[6].rsplit(":", 1)[-1], f[5], f[22], f[23], f[25]))
for r in sorted(rows): print("| " + " | ".join(r) + " |")
' "$SINCE" | tee "$OUT/mtls-log-summary.md"
