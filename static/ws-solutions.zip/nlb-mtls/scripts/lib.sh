# lib.sh — 실습 스크립트 공통 값과 함수. 다른 스크립트에서 source 합니다.
# 참석자 환경은 AWS_REGION=us-east-1(Bedrock용)이므로 모든 aws 명령에 --region "$R"를 붙입니다.

R="${LAB_REGION:-ap-northeast-2}"
STACK="${STACK:-ws-ai-nssa-nlb-mtls}"
LAB_DIR="${LAB_DIR:-$HOME/ws-lab}"
CERT_DIR="${CERT_DIR:-$LAB_DIR/certs}"
STATE_FILE="${STATE_FILE:-$LAB_DIR/.lab-state}"

account_id() { aws sts get-caller-identity --region "$R" --query Account --output text; }
artifact_bucket() { echo "ws-ai-nssa-mtls-$(account_id)-${R}"; }

# stack_output <OutputKey>
stack_output() {
  aws cloudformation describe-stacks --region "$R" --stack-name "$STACK" \
    --query "Stacks[0].Outputs[?OutputKey=='$1'].OutputValue" --output text
}

# state_get / state_set: 스크립트 사이에 넘길 값(ACM ARN, 주입한 장애 등)
state_get() { [[ -f "$STATE_FILE" ]] && grep -E "^$1=" "$STATE_FILE" | tail -1 | cut -d= -f2- || true; }
state_set() {
  mkdir -p "$(dirname "$STATE_FILE")"; touch "$STATE_FILE"
  grep -vE "^$1=" "$STATE_FILE" > "$STATE_FILE.tmp" || true
  echo "$1=$2" >> "$STATE_FILE.tmp"; mv "$STATE_FILE.tmp" "$STATE_FILE"
}

log() { printf '\033[1;34m[%s]\033[0m %s\n' "$(date +%H:%M:%S)" "$*"; }
