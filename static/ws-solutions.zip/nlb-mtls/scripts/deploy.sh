#!/usr/bin/env bash
# deploy.sh — 인증서 업로드, ACM import, CloudFormation 배포를 한 번에 합니다.
#   1) S3 artifact 버킷 생성 + trust store 파일/클라이언트 인증서 업로드
#   2) 서버 인증서 ACM import (한 번만, ARN은 .lab-state에 저장)
#   3) infra/nlb-mtls.yaml 배포 (스택 ws-ai-nssa-nlb-mtls)
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/lib.sh

[[ -f "$CERT_DIR/ca-bundle.pem" ]] || { echo "먼저 OUT_DIR=$CERT_DIR scripts/gen-certs.sh 를 실행하세요." >&2; exit 1; }

BUCKET="$(artifact_bucket)"
log "artifact 버킷: s3://$BUCKET ($R)"
OWNER="$(aws sts get-caller-identity --region "$R" --query Account --output text)"
# A predictable bucket name could be pre-created by someone else: only reuse a bucket this account owns.
if aws s3api head-bucket --region "$R" --bucket "$BUCKET" --expected-bucket-owner "$OWNER" >/dev/null 2>&1; then
  log "기존 artifact 버킷 사용(소유 계정 확인됨): $BUCKET"
elif aws s3api head-bucket --region "$R" --bucket "$BUCKET" >/dev/null 2>&1; then
  echo "버킷 $BUCKET 이 이미 있지만 이 계정 소유가 아닙니다. 중단합니다." >&2; exit 1
else
  aws s3api create-bucket --region "$R" --bucket "$BUCKET" \
    --create-bucket-configuration LocationConstraint="$R" >/dev/null
  aws s3api put-public-access-block --region "$R" --bucket "$BUCKET" \
    --public-access-block-configuration BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true
  aws s3api put-bucket-tagging --region "$R" --bucket "$BUCKET" --tagging 'TagSet=[{Key=Project,Value=ws-ai-nssa}]'
fi

log "trust store 파일 업로드 (CA 번들, CRL)"
aws s3 cp --region "$R" "$CERT_DIR/ca-bundle.pem" "s3://$BUCKET/truststore/ca-bundle.pem"
aws s3 cp --region "$R" "$CERT_DIR/crl.pem"       "s3://$BUCKET/truststore/crl.pem"

log "클라이언트 인증서 업로드 (실습용 키 포함 — 실습이 끝나면 cleanup.sh가 지웁니다)"
for f in "$CERT_DIR"/client-*.pem "$CERT_DIR"/client-*.key "$CERT_DIR/lab-root-ca.pem"; do
  aws s3 cp --region "$R" --only-show-errors "$f" "s3://$BUCKET/clients/$(basename "$f")"
done

CERT_ARN="$(state_get server_cert_arn)"
if [[ -z "$CERT_ARN" ]]; then
  log "서버 인증서 ACM import"
  CERT_ARN="$(aws acm import-certificate --region "$R" \
    --certificate "fileb://$CERT_DIR/server.pem" \
    --private-key "fileb://$CERT_DIR/server.key" \
    --certificate-chain "fileb://$CERT_DIR/server-chain.pem" \
    --tags Key=Project,Value=ws-ai-nssa \
    --query CertificateArn --output text)"
  state_set server_cert_arn "$CERT_ARN"
fi
log "서버 인증서: $CERT_ARN"

log "CloudFormation 배포: $STACK (10분 안팎)"
aws cloudformation deploy --region "$R" \
  --stack-name "$STACK" \
  --template-file infra/nlb-mtls.yaml \
  --capabilities CAPABILITY_IAM \
  --tags Project=ws-ai-nssa \
  --parameter-overrides "ArtifactBucket=$BUCKET" "ServerCertificateArn=$CERT_ARN"

aws cloudformation describe-stacks --region "$R" --stack-name "$STACK" \
  --query 'Stacks[0].Outputs[].[OutputKey,OutputValue]' --output table
