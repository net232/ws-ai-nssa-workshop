#!/usr/bin/env bash
# test-matrix.sh — 클라이언트 EC2에서 실행합니다(SSM). 인증서별로 NLB에 접속해
# 기대값과 실제값을 비교한 Markdown 표를 출력합니다.
#
#   PHASE=base   : 필터 없음 (Lab 3 1단계)
#   PHASE=filter : client certificate identity filter 적용 후 (Lab 3 2단계)
#
# 환경 변수: NLB_DNS(필수, /etc/profile.d/lab.sh), SERVER_NAME, CERTS, PHASE
set -uo pipefail

NLB_DNS="${NLB_DNS:?NLB_DNS 가 필요합니다 (source /etc/profile.d/lab.sh)}"
SERVER_NAME="${SERVER_NAME:-mtls.lab.internal}"
CERTS="${CERTS:-/opt/lab/certs}"
PHASE="${PHASE:-base}"
MTLS_PORT="${MTLS_PORT:-443}"
PLAIN_PORT="${PLAIN_PORT:-8443}"

# case | cert(없으면 -) | port | base 기대값 | filter 기대값 | 기대 tls_verify_status
CASES=(
  "valid|client-valid|$MTLS_PORT|ACCEPT|ACCEPT|Success"
  "no-cert|-|$MTLS_PORT|REJECT|REJECT|Failed:ClientCertMissing"
  "other-ca|client-other-ca|$MTLS_PORT|REJECT|REJECT|Failed:ClientCertUntrusted"
  "revoked|client-revoked|$MTLS_PORT|REJECT|REJECT|Failed:ClientCertCrlHit"
  "eku-serverAuth|client-eku-server|$MTLS_PORT|REJECT|REJECT|Failed:ClientCertPurposeInvalid"
  "no-eku|client-no-eku|$MTLS_PORT|ACCEPT|ACCEPT|Success"
  "expired|client-expired|$MTLS_PORT|REJECT|REJECT|Failed:ClientCertExpired"
  "ou-staging|client-staging|$MTLS_PORT|ACCEPT|REJECT|base Success / filter Failed:CertificateFilterNoMatch"
  "uri-only|client-uri-only|$MTLS_PORT|ACCEPT|ACCEPT|Success (OU 불일치, SAN.URI prefix 일치 → OR)"
  "plain:no-cert|-|$PLAIN_PORT|ACCEPT|ACCEPT|Success (mTLS off)"
  "plain:other-ca|client-other-ca|$PLAIN_PORT|ACCEPT|ACCEPT|Success (mTLS off)"
)

# 판정
#   ACCEPT : curl rc=0 이고 HTTP 200
#   REJECT : TCP 연결은 됐지만 TLS 단계에서 NLB가 끊음 (rc 35 SSL connect, 52 empty reply, 55 send, 56 recv)
#            리허설(curl 8.21.0, OpenSSL 3.5.8)에서는 35와 56만 나왔고, 같은 케이스도 실행마다 35/56이 바뀌었습니다.
#   ERROR  : 그 밖의 모든 경우 — 인증서 파일 없음, DNS(6), 연결 실패(7), 시간 초과(28),
#            서버 인증서 검증 실패(60), 로컬 인증서 문제(58) 등. 테스트가 성립하지 않았으므로 FAIL.
REJECT_RC=" 35 52 55 56 "

probe() {  # probe <cert|-> <port>  -> "<verdict> <http_code> <curl_rc> <msg>"
  local cert="$1" port="$2" args=()
  if [[ "$cert" != "-" ]]; then
    for f in "$CERTS/$cert.pem" "$CERTS/$cert.key"; do
      [[ -r "$f" ]] || { echo "ERROR - - 파일 없음/읽기 불가: $f"; return; }
    done
    args=(--cert "$CERTS/$cert.pem" --key "$CERTS/$cert.key")
  fi
  [[ -r "$CERTS/lab-root-ca.pem" ]] || { echo "ERROR - - 파일 없음: $CERTS/lab-root-ca.pem"; return; }
  local out rc verdict
  out="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 5 \
        --cacert "$CERTS/lab-root-ca.pem" \
        --connect-to "$SERVER_NAME:$port:$NLB_DNS:$port" \
        "${args[@]}" "https://$SERVER_NAME:$port/" 2>/tmp/probe.err)"
  rc=$?
  if [[ $rc -eq 0 && "$out" == "200" ]]; then verdict=ACCEPT
  elif [[ "$REJECT_RC" == *" $rc "* ]]; then verdict=REJECT
  else verdict=ERROR
  fi
  echo "$verdict ${out:-000} $rc $(tr '\n' ' ' </tmp/probe.err | cut -c1-80)"
}

pass=0; fail=0
echo "## mTLS test matrix — phase=$PHASE, $(date -u +%FT%TZ)"
echo
echo "| # | case | port | cert | expected | actual | curl rc | detail | 기대 로그 |"
echo "|---|---|---|---|---|---|---|---|---|"
i=0
for row in "${CASES[@]}"; do
  IFS='|' read -r name cert port exp_base exp_filter exp_log <<<"$row"
  i=$((i+1))
  expected="$exp_base"; [[ "$PHASE" == "filter" ]] && expected="$exp_filter"
  read -r actual code rc msg <<<"$(probe "$cert" "$port")"
  mark="✅"; if [[ "$actual" == "$expected" ]]; then pass=$((pass+1)); else fail=$((fail+1)); mark="❌"; fi
  [[ "$actual" == ERROR ]] && mark="⚠️"
  echo "| $i | $name | $port | $cert | $expected | $actual $mark | $rc | ${msg:-http $code} | $exp_log |"
done
echo
echo "결과: PASS $pass / FAIL $fail (ERROR는 FAIL에 포함)"
[[ $fail -eq 0 ]]
