#!/usr/bin/env bash
# inject-fault.sh — Lab 4 장애 주입. 무엇을 바꿨는지는 출력하지 않습니다(진단 연습).
#   사용법: scripts/inject-fault.sh <1|2|3|4|random>
#     1  backend 경로 장애     (target SG에서 NLB → 8080 인바운드 제거)
#     2  trust store 장애      (CA 번들을 다른 CA로 교체)
#     3  revocation 장애       (잘못된 CRL 추가: 정상 클라이언트 인증서를 폐기)
#     4  identity filter 장애  (오타·대소문자가 틀린 필터 적용)
# 한 번에 하나만 주입합니다. 되돌리기: scripts/fix-fault.sh (정답지)
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/lib.sh

CUR="$(state_get fault)"
[[ -n "$CUR" ]] && { echo "이미 주입된 장애가 있습니다. 먼저 해결하거나 scripts/fix-fault.sh 를 실행하세요." >&2; exit 1; }

N="${1:?1|2|3|4|random}"
[[ "$N" == random ]] && N=$(( (RANDOM % 4) + 1 ))
BUCKET="$(artifact_bucket)"
TS="$(stack_output TrustStoreArn)"

case "$N" in
  1)
    TSG="$(stack_output TargetSecurityGroupId)"; NSG="$(stack_output NlbSecurityGroupId)"
    aws ec2 revoke-security-group-ingress --region "$R" --group-id "$TSG" \
      --ip-permissions "IpProtocol=tcp,FromPort=8080,ToPort=8080,UserIdGroupPairs=[{GroupId=$NSG}]" >/dev/null ;;
  2)
    aws s3 cp --region "$R" --only-show-errors "$CERT_DIR/ca-bundle-wrong.pem" "s3://$BUCKET/truststore/ca-bundle-wrong.pem"
    aws elbv2 modify-trust-store --region "$R" --trust-store-arn "$TS" \
      --ca-certificates-bundle-s3-bucket "$BUCKET" --ca-certificates-bundle-s3-key truststore/ca-bundle-wrong.pem >/dev/null ;;
  3)
    # CA 데이터베이스 사본에서 client-valid 를 폐기한 CRL을 만듭니다(원본 CA 상태는 그대로 둠).
    TMP="$(mktemp -d)"; cp -r "$CERT_DIR"/. "$TMP"/
    export CLIENT_SAN="DNS:unused"   # openssl.cnf의 [client] 섹션이 참조하는 변수
    ( cd "$TMP"
      openssl ca -config ca-lab-root-ca/openssl.cnf -revoke client-valid.pem -crl_reason superseded 2>/dev/null
      openssl ca -config ca-lab-root-ca/openssl.cnf -gencrl -out crl-2.pem 2>/dev/null )
    aws s3 cp --region "$R" --only-show-errors "$TMP/crl-2.pem" "s3://$BUCKET/truststore/crl-2.pem"
    rm -rf "$TMP"
    RID="$(aws elbv2 add-trust-store-revocations --region "$R" --trust-store-arn "$TS" \
      --revocation-contents "RevocationType=CRL,S3Bucket=$BUCKET,S3Key=truststore/crl-2.pem" \
      --query 'TrustStoreRevocations[0].RevocationId' --output text)"
    state_set fault3_revocation_id "$RID" ;;
  4)
    L="$(stack_output MtlsListenerArn)"
    aws elbv2 modify-listener --region "$R" --listener-arn "$L" --mutual-authentication "$(cat <<JSON
{"Mode":"verify","TrustStoreArn":"$TS","ClientCertificateIdentityFilters":[
  {"Field":"subject-ou","Action":"accept","MatchType":"exact","Value":"Prod"},
  {"Field":"san-uri","Action":"accept","MatchType":"prefix","Value":"spiffe://lab.internal/NS/prod/"}]}
JSON
)" >/dev/null ;;
  *) echo "1|2|3|4|random" >&2; exit 2 ;;
esac
state_set fault "$N"
log "장애를 주입했습니다. 3분쯤 기다린 뒤(설정 반영에 1–2.5분) test-matrix 로 증상을 확인하고 Claude Code와 진단을 시작하세요."
