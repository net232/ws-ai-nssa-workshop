# Track A 정답 산출물: NLB mutual TLS 테스트

강사용 참고본입니다. 참석자는 Lab 1–4에서 Claude Code로 같은 것을 `~/ws-lab`에 직접 만듭니다.
막혔을 때 이 폴더를 `~/ws-lab`에 복사해 이어 갈 수 있습니다.

| 파일 | Lab | 내용 |
|---|---|---|
| `research.md` | 1 | 조사 노트(출처 S1–S11, 문서 불일치, 확인 필요 목록) |
| `test-plan.md` | 1 | 테스트 계획서(매트릭스 T1–T11, 비용, 정리) |
| `infra/nlb-mtls.yaml` | 2 | VPC·NLB(:443 mTLS verify, :8443 off)·trust store·CRL·EC2 3대 |
| `scripts/gen-certs.sh` | 2 | CA 2개, 서버 인증서, 클라이언트 인증서 7종, CRL |
| `scripts/local-rehearsal.sh` | 2 | 배포 전 `openssl s_server`로 매트릭스 리허설 |
| `scripts/deploy.sh` | 2 | S3 업로드 → ACM import → 스택 배포 |
| `scripts/test-matrix.sh` | 3 | 클라이언트에서 실행하는 매트릭스 테스트(Markdown 표 출력) |
| `scripts/run-on-client.sh` | 3 | SSM Run Command로 클라이언트에서 스크립트 실행 |
| `scripts/apply-filters.sh` | 3 | identity filter 켜기/끄기/보기(CLI) |
| `scripts/fetch-logs.sh` | 3 | access log 수집, mTLS 필드 요약 |
| `results-template.md` | 3 | 결과 보고서 틀 |
| `scripts/inject-fault.sh` / `fix-fault.sh` | 4 | 장애 4종 주입 / 정답 복구 |
| `rca-example.md` | 4 | 원인 분석 보고서 예시 |
| `scripts/cleanup.sh` | 정리 | 리소스 전체 삭제 |
| `rehearsal.md` | 강사 | 2026-11-26 라이브 리허설 기록(실제 매트릭스·로그·장애 증상) |

## 실행 순서

```bash
cp -r solutions/nlb-mtls/{infra,scripts} ~/ws-lab/
cd ~/ws-lab
export LAB_REGION=ap-northeast-2          # AWS_REGION(us-east-1, Bedrock용)과 별개
OUT_DIR=~/ws-lab/certs scripts/gen-certs.sh
scripts/local-rehearsal.sh                 # 선택: 로컬 리허설 (PASS 11 / FAIL 0)
scripts/deploy.sh                          # 5분 안팎(리허설 4분 11초)
scripts/run-on-client.sh scripts/test-matrix.sh PHASE=base
scripts/apply-filters.sh on
sleep 180                                  # 필터 반영 지연(리허설 약 2분 16초)
scripts/run-on-client.sh scripts/test-matrix.sh PHASE=filter
sleep 600; scripts/fetch-logs.sh 30        # access log는 5분 단위로 전달
scripts/inject-fault.sh random             # Lab 4 (주입·복구 모두 반영까지 1–3분)
scripts/cleanup.sh
```

- 스택 이름: `ws-ai-nssa-nlb-mtls` / artifact 버킷: `ws-ai-nssa-mtls-<계정>-<리전>`
- 모든 aws 명령은 `--region "$R"`(`R=${LAB_REGION:-ap-northeast-2}`)로 리전을 명시합니다.
- **AWS CLI v2 2.41.2 이상**이 필요합니다. `ClientCertificateIdentityFilters`는 CLI CHANGELOG 2.41.2의 elbv2 NLB mTLS 항목에서 들어왔습니다. 2.38.0에는 없고, 리허설은 2.42.4로 했습니다. `aws elbv2 modify-listener help | grep ClientCertificateIdentityFilters`로 확인합니다.
- `jq`, `python3`, `openssl`, `curl`이 필요합니다(Workshop IDE에는 설치되어 있음). 스크립트는 Linux(Amazon Linux 2023, OpenSSL 3)에서 검증했습니다. macOS(LibreSSL)는 검증하지 않았으므로 Workshop IDE에서 실행하세요.

## 설계 결정

### 비교 리스너를 "passthrough"가 아니라 "mTLS off"로 둔 이유

NLB의 `MutualAuthentication.Mode`는 `off`, `verify`만 지원합니다(API 레퍼런스). `passthrough`는 ALB 전용입니다.
그런데 CloudFormation 레퍼런스의 `Mode` 설명은 ALB·NLB 구분 없이 `off`, `passthrough`, `verify`를 나열하므로
`cfn-lint`는 NLB에 `passthrough`를 써도 통과시킵니다. 실패는 배포할 때 API에서 납니다. Lab 2의 "AI 환각 잡기" 예제로 씁니다.

### identity filter를 템플릿에 넣지 않은 이유

- NLB 사용자 가이드(client-certificate-filters)는 CloudFormation `MutualAuthentication.ClientCertificateIdentityFilters` 예시를 보여 줍니다.
- CloudFormation 템플릿 레퍼런스의 `MutualAuthentication` 속성 목록에는 이 속성이 없고, `cfn-lint 1.61.0`도 `E3002`로 거부합니다.
- 출시 직후 흔한 "문서끼리 다른" 상황입니다. 실습이 이 불확실성에 막히지 않도록 필터는 Lab 3에서 CLI로 적용하고,
  CFN 지원 여부는 change set으로 따로 확인하게 합니다(확인 필요 항목).

### 권한과 키 보관

- 백엔드 EC2는 SSM 권한만 있는 `BackendRole`을 씁니다. `clients/`(클라이언트 개인 키) 읽기 권한은 클라이언트 EC2의 `ClientRole`에만 있습니다(`s3:GetObject` + `clients/` prefix 조건의 `s3:ListBucket`).
- 클라이언트는 부팅할 때 인증서를 `/opt/lab/certs`(root 전용, 키 600)에 받고, 성공·실패를 `cfn-signal`로 알립니다(`CreationPolicy`, 15분). 받지 못하면 스택 생성이 실패하므로 실패가 숨겨지지 않습니다.
- Session Manager로 들어가면 `sudo -i` 후 사용합니다. Run Command(`run-on-client.sh`)는 root로 실행됩니다.

### test-matrix 판정

| 판정 | 조건 |
|---|---|
| ACCEPT | curl 종료 코드 0, HTTP 200 |
| REJECT | TCP 연결 뒤 TLS 단계에서 끊김(curl 35, 52, 55, 56. 리허설에서는 35·56만 나옴) |
| ERROR | 그 밖의 모든 경우(인증서 파일 없음, DNS 6, 연결 실패 7, 시간 초과 28, 서버 인증서 검증 실패 60 등). FAIL로 셉니다 |

### 검증한 것 / 검증하지 않은 것

- 검증함(2026-11-26): `cfn-lint infra/nlb-mtls.yaml` 오류 없음, 모든 스크립트 `bash -n`,
  `gen-certs.sh` 실행 결과(EKU/KU/SAN/만료/CRL serial)와 `openssl verify`,
  `local-rehearsal.sh` PASS 11 / FAIL 0, `test-matrix.sh`의 ERROR 판정(인증서 파일 없음, 연결 실패),
  `gen-certs.sh`의 위험 경로·기존 폴더 거부, `fetch-logs.sh` 파서(문서의 로그 예시로 확인), 장애 3의 CRL 생성.
- 라이브 리허설(2026-11-26, ap-northeast-2, `rehearsal.md`): 배포 4분 11초, 매트릭스 base·filter 모두 PASS 11 / FAIL 0,
  access log 사유 코드 7종 확인(인증서 없음은 `Failed:ClientCertMissing`), 장애 1–4 주입·진단·복구, `cleanup.sh` 뒤 남은 리소스 0건(서비스 API 기준. 태그 API는 terminated EC2 등을 한동안 더 보여 줌).
  리허설에서 고친 것: 설정 반영 지연 안내(`apply-filters.sh`, `inject-fault.sh`, `fix-fault.sh`), `run-on-client.sh`의 공백 있는 값,
  `fetch-logs.sh` 포트 열, `test-matrix.sh` 기대 로그, `cleanup.sh`의 IDE 스택 제외.
- 검증하지 않음: CFN `ClientCertificateIdentityFilters` change set의 실행 결과, macOS(LibreSSL), AWS CLI 2.41.2 자체.
