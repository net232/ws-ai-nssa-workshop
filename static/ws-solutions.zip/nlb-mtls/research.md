# 조사 노트: NLB mutual TLS (2026-11 출시)

> Lab 1 정답 예시. 참석자 산출물 위치: `~/ws-lab/research.md`.
> 조사일 2026-11-26. 모든 항목은 아래 출처에서 확인했습니다. 확인하지 못한 항목은 **확인 필요**로 표시했습니다.

## 출처

| # | 문서 | URL |
|---|---|---|
| S1 | What's New: NLB now supports mutual TLS | https://aws.amazon.com/about-aws/whats-new/2026/11/network-load-balancer-mtls/ |
| S2 | 블로그: Introducing mTLS for Network Load Balancer | https://aws.amazon.com/blogs/networking-and-content-delivery/introducing-mtls-for-network-load-balancer/ |
| S3 | NLB 사용자 가이드: Mutual TLS | https://docs.aws.amazon.com/elasticloadbalancing/latest/network/mutual-authentication.html |
| S4 | NLB 사용자 가이드: Configure mutual TLS | https://docs.aws.amazon.com/elasticloadbalancing/latest/network/configure-mutual-authentication.html |
| S5 | NLB 사용자 가이드: Client certificate identity filters | https://docs.aws.amazon.com/elasticloadbalancing/latest/network/client-certificate-filters.html |
| S6 | NLB 사용자 가이드: Access logs (필드, 오류 코드) | https://docs.aws.amazon.com/elasticloadbalancing/latest/network/load-balancer-access-logs.html |
| S7 | NLB 쿼터 | https://docs.aws.amazon.com/elasticloadbalancing/latest/network/load-balancer-limits.html |
| S8 | API: MutualAuthenticationAttributes | https://docs.aws.amazon.com/elasticloadbalancing/latest/APIReference/API_MutualAuthenticationAttributes.html |
| S9 | CFN: AWS::ElasticLoadBalancingV2::Listener MutualAuthentication | https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-properties-elasticloadbalancingv2-listener-mutualauthentication.html |
| S10 | NLB access logs 버킷 정책 | https://docs.aws.amazon.com/elasticloadbalancing/latest/network/enable-access-logs.html |
| S11 | AWS Price List API (AWSELB, ap-northeast-2, 2026-11-25 게시본) | `get_pricing AWSELB ap-northeast-2` |

## 핵심 사실

| 항목 | 내용 | 출처 |
|---|---|---|
| 지원 모드 | NLB는 **verify 모드만** 지원. `Mode` 값은 `off`, `verify`. (`passthrough`는 ALB 전용) | S3, S8 |
| 적용 대상 | TLS 리스너. trust store는 리스너당 1개, 한 trust store를 여러 리스너가 공유 가능 | S4 |
| 검사 순서 | 신뢰 체인 → identity filter → revocation(CRL) | S3, S5 |
| 인증서 요구 | X.509v3, RSA 2K–8K 또는 ECDSA P-256/384/521, SHA256/384/512 서명 | S3 |
| EKU/KU | EKU가 **있으면** `clientAuth` 필수, KU가 **있으면** `digitalSignature` 또는 `keyAgreement` 필수. 확장이 없으면 그 검사는 생략(RFC 5280) | S3 |
| 체인 제한 | 체인 깊이 최대 4, 체인 크기 16 KB, leaf subject DN 1,024 bytes | S3, S7 |
| CA 번들 파일 | PEM, 빈 줄 금지, 주석은 `#`로 시작하고 `-` 문자 금지. 번들은 통째로 교체(`ModifyTrustStore`) | S3 |
| CRL | PEM만 지원. 음수 serial은 무시. 추가할 때마다 revocation ID 증가. NLB는 추가 시점에 가져오며 연결마다 S3를 읽지 않음 | S4, S2 |
| 세션 재개 | mTLS verify 모드에서 session resumption 미지원 | S3 |
| 만료 인증서 | 기본 거부. `IgnoreClientCertificateExpiry=true`면 허용 | S4 |
| CA 이름 광고 | `AdvertiseTrustStoreCaNames=on`이면 CertificateRequest에 CA DN 포함. 기본 off | S4 |
| identity filter | 필드 `subject-cn`, `subject-ou`, `san-dns`, `san-uri` / 매치 `exact`, `prefix` / action은 `accept`만 / OR 결합 / 리스너당 100개 / 값 1–256 printable ASCII | S5, S8 |
| 대소문자 | CN·OU·SAN.DNS는 대소문자 무시. SAN.URI는 scheme·host만 무시, **경로는 구분** | S5 |
| 백엔드 전달 | 대상은 클라이언트 인증서 정보를 받지 않음(필터로 신원 통제) | S2 |
| 헬스 체크 | 기존과 동일, mTLS 영향 없음 | S2 |
| access log | `tls_verify_status`(`Success` / `Failed:<code>`), `leaf_client_cert_subject`, `leaf_client_cert_validity`, `leaf_client_cert_serial_number`. 노드별 5분마다 전달 | S6 |
| 오류 코드 | `ClientCertUntrusted`, `ClientCertExpired`, `ClientCertNotYetValid`, `ClientCertPurposeInvalid`, `ClientCertCrlHit`, `ClientCertCrlProcessingError`, `ClientCertMaxChainDepthExceeded`, `ClientCertMaxSizeExceeded`, `ClientCertIncompatible`, `CertificateFilterNoMatch` 등 | S6 |
| 거부 증상 | TLS 1.3에서는 핸드셰이크가 끝난 뒤 첫 요청에서 reset으로 보임. curl 오류 번호는 버전마다 다름. 리허설(curl 8.21.0, OpenSSL 3.5.8)은 35·56, 같은 케이스도 실행마다 바뀜 | S2, 리허설 |
| 쿼터 | trust store당 CA 25개(조정 가능), CA 인증서 16 KB, revocation 항목 500,000, CRL 파일 50 MB, trust store당 CRL 30개 | S7 |
| 요금 | NLB $0.0225/h, LCU $0.006/LCU-h, **NLB에 연결된 trust store $0.005/h** (ap-northeast-2). 필터는 추가 비용 없음 | S11, S2 |

## 도구 지원 (CLI / CloudFormation)

| 작업 | CLI | CloudFormation | 출처 |
|---|---|---|---|
| trust store | `aws elbv2 create-trust-store` | `AWS::ElasticLoadBalancingV2::TrustStore` (`CaCertificatesBundleS3Bucket`, `CaCertificatesBundleS3Key`) | S4 |
| CRL | `aws elbv2 add-trust-store-revocations` | `AWS::ElasticLoadBalancingV2::TrustStoreRevocation` (`RevocationContents[].RevocationType: CRL`, `S3Bucket`, `S3Key`) | S4 |
| 리스너 mTLS | `--mutual-authentication Mode=verify,TrustStoreArn=...` | `Listener.MutualAuthentication` (`Mode`, `TrustStoreArn`, `IgnoreClientCertificateExpiry`, `AdvertiseTrustStoreCaNames`) | S4, S9 |
| identity filter | `--mutual-authentication '{"ClientCertificateIdentityFilters":[...]}'` (AWS CLI v2 **2.41.2 이상**, 리허설 2.42.4) | 템플릿 레퍼런스·레지스트리 스키마에 없음(아래) | S5, S9, 리허설 |

## 문서끼리 다른 곳 (사람이 판단할 것)

1. **CFN의 `ClientCertificateIdentityFilters`**
   - S5(사용자 가이드)는 CloudFormation `MutualAuthentication` 아래 `ClientCertificateIdentityFilters` 예시를 보여 줍니다.
   - S9(CFN 템플릿 레퍼런스)의 속성 목록에는 이 속성이 없습니다. `cfn-lint 1.61.0`도 `E3002 ... 'ClientCertificateIdentityFilters' was unexpected`로 거부합니다.
   - 결정: 템플릿에는 넣지 않고, Lab 3에서 CLI(`modify-listener`)로 적용합니다. CFN 지원은 change set으로 따로 확인합니다.
   - 리허설(2026-11-26): 레지스트리 스키마(`describe-type`)의 `MutualAuthentication`에도 이 속성이 없고 `additionalProperties: false`입니다. 그런데도 change set은 `CREATE_COMPLETE`(MtlsListener `Modify`)로 만들어졌습니다. 실행은 하지 않았으므로 실제 적용 여부는 **미확인**입니다.
2. **필터 필드 표기**: 블로그·콘솔은 `Subject.CN`, `SAN.URI`처럼 표시하지만, API·CLI 값은 `subject-cn`, `san-uri`입니다(S5, S8). 스크립트에는 API 값을 씁니다.
3. **CFN 예시의 리스트 문법**: S9 예시는 `MutualAuthentication:` 아래를 `- Mode: verify` 리스트로 쓰지만, 같은 페이지의 Syntax는 객체입니다. 객체로 씁니다(cfn-lint 통과).
4. **mTLS 전용 CloudWatch 메트릭**: 블로그(S2)는 "handshake count, error count, latency, client certificate expiration" 메트릭이 있다고 하지만, 메트릭 문서 페이지에는 아직 이름이 없습니다. 배포 후 `aws cloudwatch list-metrics --region ap-northeast-2 --namespace AWS/NetworkELB`로 실제 이름을 확인합니다.
   - 리허설(배포 후 약 30분): 이름에 `Cert`, `Mutual`, `mTLS`, `Handshake`가 들어간 지표는 없었습니다. mTLS 거부는 `ClientTLSNegotiationErrorCount`에 세어졌습니다.

## 확인 필요 목록

리허설(2026-11-26, `rehearsal.md`)로 닫은 결과입니다.

- [ ] (일부 확인) CFN `MutualAuthentication.ClientCertificateIdentityFilters` 지원 여부: 레지스트리 스키마에 없음, change set은 생성됨, **실행 결과 미확인**
- [x] mTLS 전용 CloudWatch 메트릭 이름: 30분 동안 발행되지 않음. 거부는 `ClientTLSNegotiationErrorCount`에 포함
- [x] 인증서를 보내지 않은 클라이언트의 `tls_verify_status` 값: `Failed:ClientCertMissing`
- [x] CA 번들을 다른 CA로 바꿨을 때 기존 CRL의 처리: revocation ID 1이 그대로 남고 trust store는 `ACTIVE`
- [x] 추가로 확인: 거부된 연결은 access log의 subject·serial이 `-`. 8443(mTLS off)도 `tls_verify_status`는 `Success`. 설정 변경 반영은 45초–2분 16초
