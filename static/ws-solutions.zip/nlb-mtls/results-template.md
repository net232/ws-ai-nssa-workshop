# 테스트 결과: NLB mutual TLS

> Lab 3 산출물 틀. 참석자 산출물 위치: `~/ws-lab/results.md`. 값은 **실제 명령 출력에서만** 채웁니다.

- 실행 일시(UTC): <YYYY-MM-DDTHH:MM>
- 스택: `ws-ai-nssa-nlb-mtls`, 리전 `ap-northeast-2`
- NLB: `<NlbArn>` / 리스너 443 `<MtlsListenerArn>` / 8443 `<PlainTlsListenerArn>`
- trust store: `<TrustStoreArn>` (CA <NumberOfCaCertificates>개, revocation <N>개)

## 1. 매트릭스 결과

### 1단계: 필터 없음 (`PHASE=base`)

<test-matrix.sh 출력 표를 그대로 붙임>

### 2단계: 필터 적용 (`PHASE=filter`)

필터 설정(`scripts/apply-filters.sh show` 출력):

```json
<붙임>
```

<test-matrix.sh 출력 표를 그대로 붙임>

## 2. access log 증적

<fetch-logs.sh 출력 표. 케이스마다 tls_verify_status와 subject 대조>

| 테스트 ID | 기대 tls_verify_status | 로그의 값 | 일치 |
|---|---|---|---|
| T1 | Success | | |
| T3 | Failed:ClientCertUntrusted | | |
| ... | | | |

## 3. 메트릭

`aws cloudwatch list-metrics --region ap-northeast-2 --namespace AWS/NetworkELB --dimensions Name=LoadBalancer,Value=<net/...>` 결과에서 mTLS 관련 메트릭 이름:

- <이름> — <값>

## 4. 기대와 다른 결과

| 테스트 ID | 기대 | 실제 | 원인 분류(문서/설정/테스트) | 근거 |
|---|---|---|---|---|

## 5. "확인 필요" 항목 결과

| 항목 | 결과 | 근거 |
|---|---|---|
| CFN `ClientCertificateIdentityFilters` | | change set 출력 |
| mTLS 메트릭 이름 | | list-metrics 출력 |
| 인증서 없음 사유 코드 | | access log |

## 6. 결론과 워크숍 소재로 쓸 점
