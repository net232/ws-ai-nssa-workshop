# 라이브 리허설 기록: Track A (NLB mutual TLS)

> 강사용. 정답 스크립트(`scripts/`)와 템플릿(`infra/nlb-mtls.yaml`)을 실제 계정에 처음 배포해 끝까지 돌린 기록입니다.
> 계정 ID는 `111122223333`으로 가렸습니다.

## 1. 환경

| 항목 | 값 |
|---|---|
| 날짜 | 2026-11-26 21:20–22:00 UTC (2026-11-27 06:20–07:00 KST) |
| 리전 | `ap-northeast-2` (`LAB_REGION`) |
| 실행 호스트 | Amazon Linux 2023 (aarch64), OpenSSL 3, `cfn-lint 1.61.0` |
| AWS CLI | **2.42.4** (scratch 설치). 시스템 CLI 2.38.0에는 `ClientCertificateIdentityFilters`가 없음 |
| 클라이언트 EC2 | AL2023 arm64 t4g.micro, `curl 8.21.0`, `OpenSSL 3.5.8` |
| 스택 / 버킷 | `ws-ai-nssa-nlb-mtls` / `ws-ai-nssa-mtls-111122223333-ap-northeast-2` |

AWS CLI 최소 버전: CLI v2 CHANGELOG에서 elbv2 NLB mTLS API(`ClientCertificateIdentityFilters` 포함)가 들어간 버전은 **2.41.2**입니다. 리허설은 2.42.4로 했고, `aws elbv2 modify-listener help`에 `ClientCertificateIdentityFilters`가 나오는지로 확인했습니다. 2.41.2 자체로는 실행해 보지 않았습니다.

## 2. 단계별 소요 시간

| 단계 | 시각(UTC) | 소요 | 비고 |
|---|---|---|---|
| CLI 설치, 파일 복사, `gen-certs.sh`, `local-rehearsal.sh` | 21:20–21:21 | 1분 | 로컬 PASS 11 / FAIL 0 |
| `deploy.sh`: 버킷·업로드·ACM import | 21:20:49–21:21:03 | 15초 | |
| `deploy.sh`: 스택 생성 | 21:21:04–21:25:15 | **4분 11초** | 페이지의 "10분 안팎"보다 빠름 |
| 그중 Client `cfn-signal` | 21:24:21 부팅 → 21:25:13 SUCCESS | 52초 | `dnf install aws-cfn-bootstrap` 정상 |
| 매트릭스 base | 21:25:49 | 5초 | PASS 11 / FAIL 0 |
| 필터 적용 → 매트릭스 filter | 21:25:58 적용, 21:28:24 PASS | 2분 30초 | 반영 지연(아래 4절) |
| change set 확인, passthrough 함정, T11 | 21:26–21:31 | 5분 | |
| 장애 1–4 주입·확인·복구 | 21:31:09–21:41:26 | 10분 | 장애당 2–3분 |
| access log 수집 | 21:42–21:48 | 5분 주기 | 마지막 행(21:42:59)은 21:47에 도착 |
| `cleanup.sh` | 21:48:07–21:56:44 | **8분 37초** | 스택 삭제가 대부분(NAT GW, EC2) |

## 3. 매트릭스 결과

### base (필터 없음) — 2026-11-26T21:25:49Z

| # | case | port | cert | expected | actual | curl rc | detail |
|---|---|---|---|---|---|---|---|
| 1 | valid | 443 | client-valid | ACCEPT | ACCEPT ✅ | 0 | http 200 |
| 2 | no-cert | 443 | - | REJECT | REJECT ✅ | 56 | curl: (56) Send failure: Connection reset by peer |
| 3 | other-ca | 443 | client-other-ca | REJECT | REJECT ✅ | 35 | curl: (35) Recv failure: Connection reset by peer |
| 4 | revoked | 443 | client-revoked | REJECT | REJECT ✅ | 56 | curl: (56) OpenSSL SSL_read: OpenSSL/3.5.8: error:0A0001BB:SSL routines::bad record type |
| 5 | eku-serverAuth | 443 | client-eku-server | REJECT | REJECT ✅ | 56 | curl: (56) Send failure: Connection reset by peer |
| 6 | no-eku | 443 | client-no-eku | ACCEPT | ACCEPT ✅ | 0 | http 200 |
| 7 | expired | 443 | client-expired | REJECT | REJECT ✅ | 35 | curl: (35) Recv failure: Connection reset by peer |
| 8 | ou-staging | 443 | client-staging | ACCEPT | ACCEPT ✅ | 0 | http 200 |
| 9 | uri-only | 443 | client-uri-only | ACCEPT | ACCEPT ✅ | 0 | http 200 |
| 10 | plain:no-cert | 8443 | - | ACCEPT | ACCEPT ✅ | 0 | http 200 |
| 11 | plain:other-ca | 8443 | client-other-ca | ACCEPT | ACCEPT ✅ | 0 | http 200 |

결과: **PASS 11 / FAIL 0**

### filter (OU exact `Production` OR SAN.URI prefix `spiffe://lab.internal/ns/prod/`) — 2026-11-26T21:28:24Z

| # | case | port | expected | actual | curl rc |
|---|---|---|---|---|---|
| 1 | valid | 443 | ACCEPT | ACCEPT ✅ | 0 |
| 2 | no-cert | 443 | REJECT | REJECT ✅ | 56 |
| 3 | other-ca | 443 | REJECT | REJECT ✅ | 56 |
| 4 | revoked | 443 | REJECT | REJECT ✅ | 56 |
| 5 | eku-serverAuth | 443 | REJECT | REJECT ✅ | 56 |
| 6 | no-eku | 443 | ACCEPT | ACCEPT ✅ | 0 |
| 7 | expired | 443 | REJECT | REJECT ✅ | 56 |
| 8 | ou-staging | 443 | REJECT | REJECT ✅ | 56 |
| 9 | uri-only | 443 | ACCEPT | ACCEPT ✅ | 0 |
| 10 | plain:no-cert | 8443 | ACCEPT | ACCEPT ✅ | 0 |
| 11 | plain:other-ca | 8443 | ACCEPT | ACCEPT ✅ | 0 |

결과: **PASS 11 / FAIL 0**. uri-only가 필터 뒤에도 통과했으므로 OR 동작이 확인되었습니다.

필터를 적용한 직후(21:26:03, 21:26:12, 21:27:24, 21:27:44)에는 ou-staging이 계속 ACCEPT여서 **PASS 10 / FAIL 1**이었습니다. 21:28:14에 처음 거부되었습니다. `modify-listener`와 `describe-listeners`는 바로 새 필터를 돌려주지만, 데이터 경로 반영은 약 2분 16초 늦었습니다. access log에도 21:26:03, 21:26:13 batch의 ou-staging 행은 `Success`로 남았습니다.

### curl 종료 코드

- 거부는 모두 **35 또는 56**이었습니다. 52, 55는 나오지 않았습니다.
- 같은 케이스도 실행마다 코드가 달랐습니다(예: other-ca가 base에서는 35, filter에서는 56). 메시지는 `Send failure: Connection reset by peer`, `Recv failure: Connection reset by peer`, `SSL_read: ... bad record type` 셋 중 하나였습니다.
- 판정을 코드 하나에 걸지 않고 "35/52/55/56 중 하나 + HTTP 200 아님"으로 둔 `test-matrix.sh`의 설계가 맞았습니다.

## 4. access log

- 파일 이름: `nlb/AWSLogs/111122223333/elasticloadbalancing/ap-northeast-2/2026/11/26/111122223333_elasticloadbalancing_ap-northeast-2_net.ws-ai-nssa-mtls.<id>_20261126T2130Z_<hash>.log.gz`. 5분 단위이고, 같은 구간에 파일이 두 개 생기기도 했습니다.
- 필드 수는 26개이고, `fetch-logs.sh`의 인덱스(22 `tls_verify_status`, 23 subject, 25 serial)가 실제 로그와 맞았습니다.
- `time` 필드는 연결이 끝난 시각입니다. 장애 1에서 시간 초과로 끝난 연결은 curl 시각보다 약 7초 뒤로 찍혔습니다.
- 모든 행의 목적지가 NLB 노드 하나(AZ a, 클라이언트와 같은 AZ)였습니다.
- base 실행(21:25:49) 행은 수집한 파일에 없었습니다. 처음 기록된 행은 21:26:03이고, 21:47까지 전달된 파일 7개 어디에도 21:25 행은 없었습니다. 스택 완료(21:25:15) 직후 1분 안팎은 로그가 남지 않은 것으로 보입니다(원인 미확인, 11절). 대신 필터 반영 전에 돌린 21:26:03, 21:26:13 실행이 base와 같은 결과를 남겼습니다.

### 케이스별 `tls_verify_status`

| 케이스 | 기대 | 로그 | subject / serial |
|---|---|---|---|
| valid | `Success` | `Success` | `CN=client-valid.lab.internal,OU=Production,O=ws-ai-nssa` / 1001 |
| no-cert | (확인 필요) | **`Failed:ClientCertMissing`** | `-` / `-` |
| other-ca | `Failed:ClientCertUntrusted` | `Failed:ClientCertUntrusted` | `-` / `-` |
| revoked | `Failed:ClientCertCrlHit` | `Failed:ClientCertCrlHit` | `-` / `-` |
| eku-serverAuth | `Failed:ClientCertPurposeInvalid` | `Failed:ClientCertPurposeInvalid` | `-` / `-` |
| no-eku | `Success` | `Success` | `CN=client-no-eku...` / 1006 |
| expired | `Failed:ClientCertExpired` | `Failed:ClientCertExpired` | `-` / `-` |
| ou-staging (filter) | `Failed:CertificateFilterNoMatch` | `Failed:CertificateFilterNoMatch` | `-` / `-` |
| uri-only (filter) | `Success` | `Success` | `CN=client-uri-only...,OU=Engineering` / 1003 |
| 8443 (mTLS off) | subject `-` | `Success`, subject `-` | `-` / `-` |

- **거부된 연결은 subject·validity·serial이 모두 `-`로 남습니다.** 그래서 거부 행은 serial이나 subject로 케이스와 짝지을 수 없고, 시각·포트·실행 순서로 짝지어야 합니다. 거부 행은 `tls_handshake_time`도 `-`이고, 받은 바이트와 보낸 바이트는 0입니다.
- mTLS off 리스너(8443)도 `tls_verify_status`가 `-`가 아니라 `Success`로 찍혔습니다.
- 21:26:03–21:42:59에 수집한 행 209개(443: 179, 8443: 30)의 분포: `Success` 94, `Failed:ClientCertUntrusted` 28, `Failed:ClientCertCrlHit` 20, `Failed:CertificateFilterNoMatch` 20, `Failed:ClientCertExpired` 18, `Failed:ClientCertMissing` 16, `Failed:ClientCertPurposeInvalid` 13.

원본 행 예시(계정 ID, 로드 밸런서·리스너 ID, IP 주소는 예시 값으로 바꿈):

```text
tls 3.0 2026-11-26T21:36:52 net/ws-ai-nssa-mtls/0123456789abcdef <listener-443> 10.20.10.11:57384 10.20.10.21:443 5 - 0 0 - - - - - - - - - - 2026-11-26T21:36:52 Failed:ClientCertMissing "-" - -
tls 3.0 2026-11-26T21:38:21 net/ws-ai-nssa-mtls/0123456789abcdef <listener-443> 10.20.10.11:42946 10.20.10.21:443 14 7 81 219 - arn:aws:acm:ap-northeast-2:111122223333:certificate/... - TLS_AES_128_GCM_SHA256 tlsv13 x25519 mtls.lab.internal - - - 2026-11-26T21:38:21 Success "CN=client-valid.lab.internal,OU=Production,O=ws-ai-nssa" NotBefore=2026-11-26T21:20:33Z;NotAfter=2026-12-26T21:20:33Z 1001
tls 3.0 2026-11-26T21:26:03 net/ws-ai-nssa-mtls/0123456789abcdef <listener-8443> 10.20.10.11:60588 10.20.10.21:8443 8 1 86 219 - arn:aws:acm:ap-northeast-2:111122223333:certificate/... - TLS_AES_128_GCM_SHA256 tlsv13 x25519 mtls.lab.internal - - - 2026-11-26T21:26:03 Success "-" - -
```

## 5. CloudWatch 지표

`aws cloudwatch list-metrics --namespace AWS/NetworkELB`에서 이 NLB 차원으로 나온 지표 가운데 TLS와 관련된 것은 다음뿐입니다. 배포 후 약 30분 동안 확인했습니다.

- `ClientTLSNegotiationErrorCount` (LoadBalancer) — 21:03–21:43 Sum **115**. mTLS 거부가 여기에 함께 세어지는 것으로 보입니다.
- `TargetTLSNegotiationErrorCount`, `NewFlowCount_TLS`(같은 구간 Sum 173), `ActiveFlowCount_TLS`, `ProcessedBytes_TLS`, `ConsumedLCUs_TLS`

이름에 `Cert`, `Mutual`, `mTLS`, `Handshake`, `Verify`, `Trust`가 들어간 지표는 namespace 전체에서 하나도 나오지 않았습니다. 블로그가 말한 mTLS 전용 지표(handshake count, error count, latency, client certificate expiration)는 **이 리허설에서는 발행되지 않았습니다.**
`RejectedFlowCount`는 0이었습니다.

## 6. 장애 주입 4종

모두 `PHASE=filter` 기준선(PASS 11)에서 시작했습니다. "반영"은 주입·복구 명령 뒤 client-valid가 처음 바뀐 시각까지 걸린 시간입니다(15초 간격 측정).

| # | 주입 | 반영 | 매트릭스 증상 | 결정적 증거 | 복구 반영 |
|---|---|---|---|---|---|
| 1 | target SG에서 NLB SG → 8080 인바운드 제거 | **즉시**(5초 뒤 첫 시도부터 rc 28) | valid·no-eku·uri-only와 8443 두 개가 **ERROR**(curl 28, 5초 시간 초과). 거부 케이스 5개(no-cert, other-ca, revoked, eku, expired)와 ou-staging은 그대로 REJECT → PASS 6 / FAIL 5 | 로그는 valid 등이 **`Success`**, connection_time 약 7,000 ms, 바이트 0 → "mTLS는 무죄". target health는 약 45초 뒤 `unhealthy`(`Target.FailedHealthChecks`). SG 인바운드 규칙 없음 | **즉시**. 대상이 아직 `unhealthy`인 동안에도 PASS 11 (모든 대상 unhealthy → fail-open). 약 20초 뒤 `healthy` |
| 2 | CA 번들을 rogue CA로 교체(`modify-trust-store`) | 약 62초 | valid·no-eku·uri-only REJECT, **other-ca ACCEPT**(OU=Production이라 필터도 통과) → PASS 7 / FAIL 4 | 로그 `Failed:ClientCertUntrusted`(revoked·expired·staging도 Untrusted. 신뢰 체인이 먼저), other-ca는 `Success` + subject. 올라간 번들 subject `CN=ws-ai-nssa rogue CA`, SHA-256 fingerprint가 `certs/ca-bundle.pem`과 다름 | 45–60초(노드별로 반영 시점이 달라 한 번은 FAIL 1) |
| 3 | client-valid(serial 1001)를 폐기한 CRL 추가 | 약 63초 | valid만 REJECT → PASS 10 / FAIL 1 | 로그 `Failed:ClientCertCrlHit`. revocation 2개(ID 1: 1건, ID 2: **2건**), `TotalRevokedEntries` 3 | 약 79초 |
| 4 | 필터 오타(OU `Prod`, SAN.URI `/NS/prod/`) | 약 46초 | valid·no-eku·uri-only REJECT → PASS 8 / FAIL 3 | 로그 `Failed:CertificateFilterNoMatch`. **revoked도 `CertificateFilterNoMatch`**(필터가 CRL보다 먼저). `describe-listeners`의 필터 값 | 45–75초 |

### 확인한 세부 동작

- **장애 1은 REJECT가 아니라 ERROR입니다.** TLS와 mTLS 검사는 NLB에서 끝나고, 대상 연결만 막히므로 curl은 5초 시간 초과(28)로 끝납니다. mTLS 검사에서 걸리는 인증서는 계속 REJECT입니다. 그래서 "모두 실패"가 아니라 "통과해야 할 것만 ERROR"로 보입니다.
- **장애 2에서 기존 CRL**: CA 번들을 바꿔도 revocation ID 1(lab CA가 발급한 CRL, 1건)은 그대로 남았습니다. `modify-trust-store`는 성공했고 trust store는 `ACTIVE`, `TotalRevokedEntries` 1이었습니다. 번들을 되돌린 뒤에도 revoked는 다시 `ClientCertCrlHit`으로 거부되었습니다.
- **장애 3의 CRL은 2건입니다.** `inject-fault.sh`가 CA 데이터베이스 사본에서 CRL을 만들기 때문에, 이미 폐기된 client-revoked까지 들어갑니다.
- 장애 2–4와 필터·만료 설정 변경은 반영까지 45초–2분 16초 걸렸습니다. 장애 1(SG)만 즉시 반영되었습니다.

## 7. 그 밖에 확인한 것

| 항목 | 결과 | 근거 |
|---|---|---|
| CFN `ClientCertificateIdentityFilters` | `cfn-lint`는 E3002로 거부. **change set은 `CREATE_COMPLETE`**(MtlsListener `Modify`, Replacement `False`, StatusReason 없음). 실행하지 않고 삭제. CloudFormation 레지스트리 스키마(`describe-type AWS::ElasticLoadBalancingV2::Listener`)의 `MutualAuthentication` 속성은 `IgnoreClientCertificateExpiry`, `Mode`, `TrustStoreArn`, `AdvertiseTrustStoreCaNames` 넷뿐이고 `additionalProperties: false` | change set이 받아 준다고 해서 실행이 성공한다는 뜻은 아닙니다. 스키마에 없으므로 실행 단계에서 실패하거나 무시될 가능성이 큽니다. **실행 결과는 미확인** |
| 함정 A: NLB `passthrough` | `modify-listener --mutual-authentication Mode=passthrough` → `ValidationError: Mutual Authentication mode passthrough is not supported on load balancers of type 'network'` | CLI 출력 |
| 8443 리스너 `MutualAuthentication` | `{"Mode": "off"}` | `describe-listeners` |
| 443 리스너 기본값 | `AdvertiseTrustStoreCaNames: off`, `TrustStoreAssociationStatus: active`, `ClientCertificateIdentityFilters: []` | `describe-listeners` |
| T11 만료 허용 | `IgnoreClientCertificateExpiry=true` 뒤 약 55초에 expired ACCEPT, `false`로 되돌린 뒤 약 62초에 다시 REJECT | probe |
| 필터를 빼고 `modify-listener` | `Mode=verify,TrustStoreArn=...,IgnoreClientCertificateExpiry=true`처럼 필터 없이 보내면 **기존 필터 2개가 유지**됨 | `modify-listener` 응답 |
| client user data | `dnf install -y aws-cfn-bootstrap` 성공, 부팅 52초 만에 `Received SUCCESS signal` | 스택 이벤트 |
| SSM | 부팅 직후 `Online`. Run Command로 매트릭스 1회 4–5초 | `run-on-client.sh` |

## 8. 고친 버그와 변경

| 파일 | 문제 | 변경 |
|---|---|---|
| `scripts/apply-filters.sh` | 적용 직후 매트릭스를 돌리면 반영 지연 때문에 ou-staging이 FAIL | 반영까지 1–3분 걸린다고 출력하고, 끝에 `exit 0` (show가 아닐 때만 출력) |
| `scripts/inject-fault.sh` | "1분쯤 기다린 뒤"로는 부족(최대 63초 + 측정 여유) | "3분쯤 기다린 뒤(설정 반영에 1–2.5분)" |
| `scripts/fix-fault.sh` | 복구 직후 재확인하면 FAIL이 남음 | 반영 지연 안내 추가 |
| `scripts/run-on-client.sh` | `VAR=value` 값에 공백이 있으면 원격 `env`가 인자를 쪼갬(`env: 'client-valid': No such file or directory`) | `printf '%q '`로 인자를 감싸 보냄 |
| `scripts/test-matrix.sh` | no-cert 기대 로그가 "(로그로 확인)" | `Failed:ClientCertMissing`. 관측한 curl 코드(35/56) 주석 |
| `scripts/fetch-logs.sh` | listener 열이 ID 끝 6자리라 443/8443을 구분하기 어려움 | 목적지 포트(443/8443)를 출력. 거부 행은 subject가 `-`라는 주석 |
| `scripts/cleanup.sh` | 마지막 태그 확인에 Workshop IDE 스택(`ws-ai-nssa-ide`, 같은 `Project` 태그) 리소스가 섞여 "남은 리소스"로 보임 | IDE 스택 리소스를 빼고 출력, 없으면 "남은 리소스 없음". 태그 API 지연 안내 추가 |
| `scripts/cleanup.sh`, `deploy.sh` | 새 CLI(2.42.4)는 `s3api head-bucket`이 JSON(`BucketArn` 등)을 출력해 로그가 지저분함 | `>/dev/null 2>&1` |

템플릿(`infra/nlb-mtls.yaml`)과 `deploy.sh`, `gen-certs.sh`는 고칠 곳이 없었습니다.

## 9. 비용과 정리

- 리소스 생존 시간은 약 36분입니다(21:21 스택 생성 시작 → 21:56 삭제 완료). 시간당 약 $0.12–0.13(`test-plan.md` 4절)이므로 **약 $0.1** 이하로 추정합니다. LCU, S3, SSM, ACM import 비용은 무시할 수준입니다.
- 정리: `scripts/cleanup.sh` 한 번으로 끝났습니다(재시도 없음).

## 10. 정리 확인

`cleanup.sh` 종료(21:56:44) 직후 확인했습니다.

| 확인 | 결과 |
|---|---|
| 스택 `ws-ai-nssa-nlb-mtls` | `Stack with id ws-ai-nssa-nlb-mtls does not exist` |
| ACM 인증서(import한 것) | `ResourceNotFoundException`, `list-certificates`에 없음 |
| `ws-ai-nssa` 이름이 들어간 S3 버킷 | 없음(artifact 버킷, 로그 버킷 모두 삭제) |
| trust store `ws-ai-nssa-mtls`, NLB `ws-ai-nssa-mtls` | 없음 |
| VPC 수 | 배포 전과 같음 |
| `resourcegroupstaggingapi get-resources --tag-filters Key=Project,Values=ws-ai-nssa` | 직후에는 11건이 보였지만 모두 이미 지워진 리소스였습니다(EC2 `terminated`, VPC·NAT GW `NotFound`/`deleted`). 이 스택 것 5건과, 같은 계정에서 따로 검증한 `ws-ai-nssa-ide` 스택 것 6건입니다. 태그 API가 삭제를 늦게 반영하기 때문입니다. 0건이 되는 시각은 아래에 적습니다. |

태그 API 0건 확인: 22:01 UTC까지도 같은 11건이 보였습니다. terminated EC2는 태그 API에 한동안(최대 약 1시간) 남습니다. 대신 서비스 API로 다시 확인했습니다. `Project=ws-ai-nssa` 태그가 있는 실행 중·중지 EC2 0, VPC 0, NAT GW(pending/available/deleting) 0, EIP 0입니다. 따라서 **실제로 남은 리소스는 0건**입니다. 태그 API 결과가 0건이 되는 것은 직접 보지 못했습니다.

`cleanup.sh`의 마지막 확인도 같은 이유로 지운 리소스 5개를 "남아 있다"고 출력했습니다. 그래서 몇 분 뒤 다시 확인하라는 안내를 넣었습니다.

## 11. 남은 미확인 항목

- CFN `ClientCertificateIdentityFilters`를 실제로 **실행**했을 때의 결과(change set 생성까지만 확인)
- mTLS 전용 CloudWatch 지표가 나중에 발행되는지(30분 동안은 없었음)
- base 실행(배포 직후 첫 1분)의 access log 행이 빠진 이유
- AWS CLI 2.41.2에서의 실제 동작(CHANGELOG로만 확인)
- macOS(LibreSSL)에서의 스크립트 동작
- NLB 노드가 둘인데 로그에는 노드 하나만 나왔습니다. 다른 AZ 노드로 들어가는 연결의 반영 시점은 따로 재지 않았습니다.
