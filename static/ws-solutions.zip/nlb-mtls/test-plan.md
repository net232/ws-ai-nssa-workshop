# 테스트 계획: NLB mutual TLS (verify 모드)

> Lab 1 정답 예시. 참석자 산출물 위치: `~/ws-lab/test-plan.md`. 근거는 `research.md`(S1–S11).
> 2026-11-26 라이브 리허설 결과를 반영했습니다(`rehearsal.md`). T1–T10, T9b, T11 모두 기대대로 나왔습니다.

## 1. 배경과 출처

- 공지: NLB now supports mutual TLS authentication (2026-11) — S1
- 문서: S3 mutual-authentication, S4 configure, S5 filters, S6 access logs, S7 quotas
- 목적: 고객 데모·워크숍 소재로 쓰기 전에 **문서에 적힌 동작을 직접 재현**하고, 거부 사유가 access log에 어떻게 남는지 확인합니다.

## 2. 확인할 질문

1. trust store CA가 서명하지 않은 인증서, 만료 인증서, EKU가 맞지 않는 인증서는 거부되는가? 사유 코드는?
2. EKU·KU 확장이 **없는** 인증서는 정말 통과하는가? (RFC 5280 동작)
3. CRL에 올린 인증서는 거부되는가? CRL을 추가하면 revocation ID는 어떻게 쌓이는가?
4. identity filter(OU exact, SAN.URI prefix)는 OR로 동작하는가(OU는 다르고 SAN.URI만 맞는 인증서가 통과하는가), 그리고 맞지 않으면 `CertificateFilterNoMatch`로 거부되는가?
5. 같은 NLB의 mTLS off 리스너와 비교했을 때 차이는 리스너 설정뿐인가?

범위 밖: AWS Private CA 연동, RAM으로 trust store 공유, AWS Load Balancer Controller, 성능 측정.

## 3. 확인된 사실 / 확인 필요

| 항목 | 내용 | 출처 | 상태 |
|---|---|---|---|
| 모드 | NLB는 `off` / `verify`만 | S3, S8 | 확인 |
| 검사 순서 | trust → filter → CRL | S3, S5 | 확인 |
| EKU/KU | 있으면 clientAuth / digitalSignature·keyAgreement 필요, 없으면 생략 | S3 | 확인 |
| 오류 코드 | `tls_verify_status = Failed:<code>` | S6 | 확인 |
| CFN 필터 속성 | 사용자 가이드와 템플릿 레퍼런스가 다름, cfn-lint 거부. 레지스트리 스키마에도 없음. change set은 생성됨 | S5, S9, 리허설 | 일부 확인(실행 결과 미확인) |
| mTLS 메트릭 이름 | 블로그에만 언급. 리허설 30분 동안 mTLS 전용 지표 없음, 거부는 `ClientTLSNegotiationErrorCount`에 포함 | S2, 리허설 | 확인(전용 지표 없음) |
| 인증서 없음 사유 코드 | `Failed:ClientCertMissing` | 리허설 | 확인 |
| 설정 반영 시간 | 필터·trust store·CRL·만료 설정 변경은 연결에 반영되기까지 45초–2분 16초. SG 변경은 즉시 | 리허설 | 확인 |

## 4. 테스트 환경

![NLB mTLS 테스트 환경](../../static/images/arch-nlb-mtls-test.svg)

- 리전 `ap-northeast-2`, VPC `10.20.0.0/16`, AZ 2개
- public subnet `10.20.0.0/24`, `10.20.1.0/24` (IGW, NAT GW 1개) / private subnet `10.20.10.0/24`, `10.20.11.0/24`
- internal NLB: TLS `:443` (mTLS verify, trust store + CRL), TLS `:8443` (mTLS off, 대조군), 서버 인증서는 lab CA가 발급해 ACM에 import
- 대상: EC2 2대(AZ별 1대, TCP 8080, Python HTTP, SSM 권한만) / 클라이언트: EC2 1대(SSM Session Manager, `clients/` 읽기 권한, 인증서는 `/opt/lab/certs`)
- S3: artifact 버킷(CA 번들, CRL, 클라이언트 인증서), 로그 버킷(access log)
- 태그 `Project=ws-ai-nssa`, 스택 `ws-ai-nssa-nlb-mtls`

### 예상 비용 (ap-northeast-2, 시간당)

| 항목 | 단가 | 출처 |
|---|---|---|
| NLB | $0.0225/h + LCU $0.006/LCU-h (실습 트래픽은 거의 0) | S11 |
| trust store (NLB 연결) | $0.005/h | S11 |
| NAT Gateway 1개 | 약 $0.059/h + 처리 GB당 요금 | 요금 페이지에서 확인 |
| EC2 t4g.micro × 3 | 약 $0.0104/h × 3 | 요금 페이지에서 확인 |
| 퍼블릭 IPv4(NAT EIP) | $0.005/h | 요금 페이지에서 확인 |
| **합계** | **약 $0.12–0.13/h** (하루 실습 6시간 ≈ $0.8) | |

리허설(2026-11-26)에서는 배포부터 정리까지 약 40분이 걸렸습니다(스택 생성 4분 11초). 추정 비용은 약 $0.1 이하입니다(`rehearsal.md`).

## 5. 테스트 매트릭스

| ID | 시나리오 | 입력/조건 | 기대 결과 | 관찰 방법 |
|---|---|---|---|---|
| T1 | 정상 클라이언트 | `client-valid` (OU=Production, clientAuth) → :443 | 허용, HTTP 200 | `test-matrix.sh`, 로그 `Success` |
| T2 | 인증서 없음 | 인증서 없이 → :443 | 거부 | curl 35/56, `Failed:ClientCertMissing` |
| T3 | 다른 CA | `client-other-ca` → :443 | 거부 | `Failed:ClientCertUntrusted` |
| T4 | CRL 폐기 | `client-revoked` → :443 | 거부 | `Failed:ClientCertCrlHit` |
| T5 | EKU 불일치 | `client-eku-server` (EKU=serverAuth) → :443 | 거부 | `Failed:ClientCertPurposeInvalid` |
| T6 | EKU·KU 없음 | `client-no-eku` → :443 | **허용** | 로그 `Success` |
| T7 | 만료 | `client-expired` (2025-01~02) → :443 | 거부 | `Failed:ClientCertExpired` |
| T8 | 필터 불일치 | 필터(OU=Production OR SAN.URI prefix `spiffe://lab.internal/ns/prod/`) 적용 후 `client-staging` | 필터 전 허용 → 필터 후 거부 | `Failed:CertificateFilterNoMatch` |
| T9 | 필터 일치(OU) | 필터 적용 후 `client-valid`, `client-no-eku` (OU=Production) | 허용 | 로그 `Success` |
| T9b | 필터 일치(SAN.URI만, OR 검증) | `client-uri-only` (OU=Engineering, SAN.URI `spiffe://lab.internal/ns/prod/sa/payments`) → 필터 전·후 | 둘 다 허용 | 로그 `Success`. 필터 후에도 허용되면 OR 동작 확인 |
| T10 | 대조군 | 인증서 없음 / `client-other-ca` → :8443 | 허용 | HTTP 200, 로그 `Success`, subject `-` |
| T11 (선택) | 만료 허용 | `IgnoreClientCertificateExpiry=true` 후 T7 | 허용 | 로그 `Success` |

## 6. 성공 기준

- T1–T10과 T9b의 실제 결과가 기대 결과와 모두 같고(`test-matrix.sh`의 ERROR 0개 포함), 거부 케이스마다 access log의 `tls_verify_status` 증적이 있다.
- 기대와 다른 결과는 "문서 오류 / 설정 오류 / 테스트 오류" 중 무엇인지 원인을 적는다.
- "확인 필요" 항목마다 확인 결과(또는 확인 불가 사유)를 `results.md`에 적는다.

## 7. 위험과 대응

| 위험 | 대응 |
|---|---|
| AI가 없는 속성·값을 만든다(예: NLB `passthrough`, CFN 필터 속성) | `cfn-lint` + 문서 대조, 문서끼리 다르면 사람이 결정 |
| 리전 누락으로 us-east-1에 생성 | 모든 명령 `--region ap-northeast-2`, 스크립트는 `LAB_REGION` 사용 |
| access log 지연(5분) | 테스트 시각을 기록하고 5–10분 뒤 수집. 거부 행은 subject·serial이 `-`이므로 시각·포트로 짝지음 |
| 설정 반영 지연(최대 약 2분) | 필터·trust store를 바꾼 뒤 3분 기다리고 매트릭스 실행 |
| 개인 키 유출 | 키는 `~/ws-lab/certs`에만, git 제외, 실습 후 삭제 |
| NAT GW 비용 누적 | 실습 직후 `cleanup.sh` |

## 8. 정리(Cleanup)

1. 로그 버킷 비우기 → 2. 스택 `ws-ai-nssa-nlb-mtls` 삭제 → 3. ACM 인증서 삭제 → 4. artifact 버킷 삭제 → 5. 로컬 키 삭제
- 남은 리소스 확인: `aws resourcegroupstaggingapi get-resources --region ap-northeast-2 --tag-filters Key=Project,Values=ws-ai-nssa`
