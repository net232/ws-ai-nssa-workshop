---
name: net-feature-test
description: AWS 신규 네트워킹 기능을 조사하고 테스트 계획, IaC, 테스트 스크립트, 결과 보고서까지 라이프사이클 순서로 진행한다. 사용자가 "신규 기능 테스트", "새 기능 검증", "/net-feature-test <기능>"을 요청할 때 사용한다.
argument-hint: "<기능 이름 또는 What's New URL>"
disable-model-invocation: true
---

# net-feature-test

대상 기능: $ARGUMENTS

아래 단계를 순서대로 진행한다. 각 단계가 끝나면 산출물 파일을 저장하고, **검증 결과를 보고한 뒤 사용자의 승인을 받고** 다음 단계로 넘어간다. 한 번에 모든 단계를 진행하지 않는다.

작업 폴더: `features/<기능-slug>/` (없으면 만든다)

## 1. Discover → `research.md`

- AWS 문서 MCP(`search_documentation`, `read_documentation`)로 What's New, 사용자 가이드, API/CLI 레퍼런스, CloudFormation 리소스 문서를 찾는다.
- 정리할 항목: 기능 요약, 동작 모드, 제약(인증서·크기·쿼터), 지원 리전, 가격, CLI 명령, CloudFormation 리소스·속성 이름, 관련 지표와 로그 필드.
- **모든 사실 옆에 출처 URL을 붙인다.** 문서에서 확인하지 못한 내용은 "미확인"으로 표시하고 추측하지 않는다.

## 2. Plan → `test-plan.md`

- `net-test-plan` skill의 템플릿을 사용한다.
- 테스트 케이스마다 **입력, 기대 결과, 판정 방법(명령과 증적)**을 적는다. 정상 경로 1개 이상, 실패해야 하는 경로 3개 이상을 포함한다.
- 아키텍처(구성 요소, CIDR, 포트), 예상 비용, 정리 방법을 적는다.
- plan mode에서 작성하고 사용자 승인 후 저장한다.

## 3. Build → `infra/`, `scripts/`

- CloudFormation은 `infra/*.yaml`, 스크립트는 `scripts/*.sh`에 둔다.
- 리소스 속성은 1단계의 CloudFormation 문서와 대조한다. `cfn-lint`를 통과해야 한다.
- 스크립트는 `set -euo pipefail`, `bash -n` 통과. 모든 `aws` 명령에 `--region "$LAB_REGION"`.
- 모든 리소스에 `Project=ws-ai-nssa` 태그. 비밀 키는 저장소에 커밋하지 않는다.

## 4. Verify → `results.md`

- 배포 명령은 실행 전에 사용자에게 보여 주고 승인을 받는다.
- 테스트를 실행하고 케이스별로 기대 결과, 실제 결과, 판정(PASS/FAIL), 증적(명령 출력 일부, 로그 줄)을 표로 정리한다.
- 기대와 다르면 테스트가 틀렸는지 기능이 다르게 동작하는지 구분해 적는다.

## 5. Troubleshoot (필요할 때) → `rca.md`

- 가설 → 확인 명령 → 결과 → 결론 순서로 기록한다. 읽기 전용 명령으로 근거를 먼저 모으고, 수정은 승인 후 한다.

## 6. Cleanup

- 만든 스택과 리소스 목록, 삭제 명령을 `cleanup.sh`로 만든다. 삭제 실행은 사용자 승인 후.
- 삭제 후 `Project=ws-ai-nssa` 태그 리소스가 남았는지 확인한다.

## 마무리 보고

각 산출물 경로, 검증하지 못한 항목, 다음에 할 일을 짧게 보고한다.
