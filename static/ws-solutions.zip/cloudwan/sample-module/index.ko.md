---
title: "2. TGW를 Cloud WAN에 연결"
weight: 20
---

<!-- Lab 5 예시 산출물: Claude Code가 storyboard.md와 AGENTS.md를 읽고 쓴 모듈 페이지를 강사가 다듬은 것입니다. "예상 출력"은 리허설 전 값입니다. -->

이 모듈에서는 서울과 도쿄의 transit gateway(TGW)를 Cloud WAN core network에 **peering**으로 연결하고, 각 TGW의 prod·dev 라우팅 테이블을 **TGW route table attachment**로 같은 이름의 세그먼트에 붙입니다. VPC와 VPC attachment는 하나도 바꾸지 않습니다.

![TGW를 Cloud WAN core network에 연결한 구조](/static/images/arch-cloudwan-after.svg)

## 목표

- TGW peering과 route table attachment가 각각 무엇을 연결하는지 설명할 수 있습니다.
- 태그 `segment=prod|dev`가 attachment policy로 세그먼트에 매핑되는 과정을 확인합니다.
- 아직 리전 간 트래픽은 기존 TGW peering을 탑니다. 왜 그런지 라우팅 테이블로 확인합니다.

::alert[이 모듈부터 core network edge 2개와 peering 2개에 시간당 요금이 붙습니다. 실습이 끝나면 [5. 정리](../50-cleanup/)를 꼭 진행하세요. 요금은 [AWS Cloud WAN 요금](https://aws.amazon.com/cloud-wan/pricing/)을 참고하세요.]{type="warning"}

## 시작하기 전에

모듈 1에서 만든 core network ID와, 모듈 0에서 만든 TGW·라우팅 테이블 ID를 변수에 담습니다.

```bash
export SEL=ap-northeast-2 TYO=ap-northeast-1
out() { aws cloudformation describe-stacks --region "$1" --stack-name "$2" \
  --query "Stacks[0].Outputs[?OutputKey=='$3'].OutputValue" --output text; }

CORE=$(out $SEL ws-ai-nssa-cwan-core CoreNetworkId); echo $CORE
```

예상 출력:

```text
core-network-0a1b2c3d4e5f67890
```

## 1단계. TGW peering과 route table attachment 만들기

::::tabs

:::tab{label="CloudFormation"}

`40-cwan-tgw-peering.yaml` 하나가 리전마다 다음 다섯 가지를 만듭니다.

| 리소스 | 역할 |
|---|---|
| `AWS::NetworkManager::TransitGatewayPeering` | 같은 리전의 core network edge와 TGW 사이 peering (BGP로 경로 교환) |
| `AWS::EC2::TransitGatewayPolicyTable` + `...Association` | peering attachment가 TGW 쪽에서 쓰는 policy table (필수 여부는 리허설에서 확인 필요) |
| `AWS::NetworkManager::TransitGatewayRouteTableAttachment` × 2 | prod RT, dev RT를 각각 core network에 붙임. 태그 `segment`가 세그먼트를 정함 |

```bash
for site in sel tyo; do
  region=$SEL; [ $site = tyo ] && region=$TYO
  aws cloudformation deploy --region $region --stack-name ws-ai-nssa-cwan-attach-$site \
    --template-file static/cfn/40-cwan-tgw-peering.yaml \
    --tags Project=ws-ai-nssa \
    --parameter-overrides SiteName=$site CoreNetworkId=$CORE \
      TransitGatewayId=$(out $region ws-ai-nssa-cwan-base-$site TransitGatewayId) \
      ProdRouteTableId=$(out $region ws-ai-nssa-cwan-base-$site ProdRouteTableId) \
      DevRouteTableId=$(out $region ws-ai-nssa-cwan-base-$site DevRouteTableId) \
    || { echo "배포 실패: $site — 스택 이벤트를 확인하세요"; break; }
done
```

:::

:::tab{label="AWS CLI"}

콘솔이나 CloudFormation 없이 같은 일을 하는 명령입니다. Network Manager API는 홈 리전 엔드포인트를 쓰므로 `--region us-west-2`로 부릅니다.

```bash
TGW_SEL=$(out $SEL ws-ai-nssa-cwan-base-sel TransitGatewayId)
ACCOUNT=$(aws sts get-caller-identity --region $SEL --query Account --output text)

aws networkmanager create-transit-gateway-peering --region us-west-2 \
  --core-network-id $CORE \
  --transit-gateway-arn arn:aws:ec2:$SEL:$ACCOUNT:transit-gateway/$TGW_SEL \
  --tags Key=Name,Value=cwan-peering-sel Key=Project,Value=ws-ai-nssa
```

다음으로 TGW 쪽 peering attachment에 policy table을 연결합니다. 콘솔에서 peering을 만들면 "Associate policy table"에서 새 policy table을 고르게 되어 있고([Create a peering](https://docs.aws.amazon.com/network-manager/latest/cloudwan/cloudwan-peerings-create.html)), API로 만드는 AWS 예시는 peering 뒤에 policy table을 따로 만들어 연결합니다([TGW → Cloud WAN 단계별 마이그레이션 블로그](https://aws.amazon.com/blogs/networking-and-content-delivery/phased-aws-transit-gateway-to-aws-cloud-wan-migration-with-terraform-and-network-mcp-server/)). CloudFormation 탭과 같게 여기서도 만듭니다.

::alert[이 단계를 건너뛰면 어떻게 되는지(필수인지)는 문서에서 확인하지 못했습니다. **리허설에서 확인 필요**입니다.]{type="warning"}

```bash
PEER_ATT=$(aws networkmanager get-transit-gateway-peering --region us-west-2 --peering-id <위 출력의 PeeringId> \
  --query 'TransitGatewayPeering.TransitGatewayPeeringAttachmentId' --output text)

PTB=$(aws ec2 create-transit-gateway-policy-table --region $SEL --transit-gateway-id $TGW_SEL \
  --tag-specifications 'ResourceType=transit-gateway-policy-table,Tags=[{Key=Name,Value=tgw-sel-cwan-policy-table},{Key=Project,Value=ws-ai-nssa}]' \
  --query 'TransitGatewayPolicyTable.TransitGatewayPolicyTableId' --output text)
# policy table이 available이 된 뒤에 연결합니다.
aws ec2 associate-transit-gateway-policy-table --region $SEL \
  --transit-gateway-policy-table-id $PTB --transit-gateway-attachment-id $PEER_ATT
```

peering이 `AVAILABLE`이 되면 라우팅 테이블을 붙입니다.

```bash
PEERING=<위 출력의 PeeringId>
PROD_RT=$(out $SEL ws-ai-nssa-cwan-base-sel ProdRouteTableId)

aws networkmanager create-transit-gateway-route-table-attachment --region us-west-2 \
  --peering-id $PEERING \
  --transit-gateway-route-table-arn arn:aws:ec2:$SEL:$ACCOUNT:transit-gateway-route-table/$PROD_RT \
  --tags Key=segment,Value=prod Key=Project,Value=ws-ai-nssa
```

dev RT와 도쿄도 같은 방법으로 붙입니다.

:::

::::

::::expand{header="왜 VPC가 아니라 TGW 라우팅 테이블을 붙이나요?"}

VPC를 core network에 직접 붙이면 VPC마다 attachment를 새로 만들고 VPC 라우팅 테이블을 바꿔야 합니다. TGW route table attachment는 이미 있는 TGW 라우팅 테이블을 세그먼트와 이어 주므로, VPC 쪽을 건드리지 않고 세그먼트 격리를 리전 간으로 넓힐 수 있습니다. 마이그레이션 첫 단계로 위험이 가장 작은 방법입니다.

::::

## 2단계. 세그먼트 매핑 확인

attachment가 태그대로 세그먼트에 들어갔는지 봅니다.

```bash
aws networkmanager list-attachments --region us-west-2 \
  --core-network-id $CORE --attachment-type TRANSIT_GATEWAY_ROUTE_TABLE \
  --query 'Attachments[].[EdgeLocation,SegmentName,State,Tags[?Key==`Name`]|[0].Value]' \
  --output table
```

예상 출력 <!-- 리허설 전 -->:

```text
---------------------------------------------------------------------
|                          ListAttachments                          |
+-----------------+-------+------------+----------------------------+
|  ap-northeast-1 |  dev  |  AVAILABLE |  tgw-tyo-dev-rt-attach     |
|  ap-northeast-1 |  prod |  AVAILABLE |  tgw-tyo-prod-rt-attach    |
|  ap-northeast-2 |  dev  |  AVAILABLE |  tgw-sel-dev-rt-attach     |
|  ap-northeast-2 |  prod |  AVAILABLE |  tgw-sel-prod-rt-attach    |
+-----------------+-------+------------+----------------------------+
```

:::alert{type="info"}
`SegmentName`이 비어 있으면 attachment policy와 맞는 규칙이 없다는 뜻입니다. 태그 키·값의 오탈자(`Segment`, `production` 등)를 먼저 확인하세요. 규칙에 맞지 않는 attachment는 어느 세그먼트에도 들어가지 않습니다.
:::

## 3단계. 라우팅 테이블 확인 — 아직 전환 전

서울 prod RT를 봅니다.

```bash
aws ec2 search-transit-gateway-routes --region $SEL \
  --transit-gateway-route-table-id $(out $SEL ws-ai-nssa-cwan-base-sel ProdRouteTableId) \
  --filters Name=state,Values=active \
  --query 'Routes[].[DestinationCidrBlock,Type,TransitGatewayAttachments[0].ResourceType]' \
  --output table
```

예상 출력 <!-- 리허설 전 -->:

```text
|  10.1.0.0/16   |  propagated |  vpc      |
|  10.11.0.0/16  |  static     |  peering  |
```

도쿄 prod VPC(`10.11.0.0/16`)로 가는 경로가 여전히 **static**(TGW 간 peering)입니다. Cloud WAN에서도 같은 CIDR이 전파되지만, TGW는 같은 목적지에 대해 정적 경로를 전파 경로보다 먼저 씁니다. 그래서 이 단계까지는 트래픽이 바뀌지 않습니다. 전환은 다음 모듈에서 정적 경로를 지워서 합니다.

## 확인

- [ ] attachment 4개가 `AVAILABLE`이고 세그먼트가 태그와 같습니다.
- [ ] 서울 prod RT의 `10.11.0.0/16`은 아직 `static`입니다.
- [ ] 서울 dev RT에는 `10.1.0.0/16`, `10.11.0.0/16`(prod)이 없습니다.

## 정리

이 모듈의 리소스는 다음 모듈에서 계속 씁니다. 여기서 끝낸다면 [5. 정리](../50-cleanup/)로 가세요.
