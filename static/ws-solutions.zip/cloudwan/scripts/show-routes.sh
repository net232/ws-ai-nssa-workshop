#!/usr/bin/env bash
# Print the prod / dev TGW route tables of both Regions (evidence for each phase).
set -euo pipefail
P=ws-ai-nssa-cwan   # stack name prefix (workshop rule: ws-ai-nssa-)
for pair in ap-northeast-2:sel ap-northeast-1:tyo; do
  region=${pair%%:*}; site=${pair##*:}
  for rt in ProdRouteTableId DevRouteTableId; do
    id=$(aws cloudformation describe-stacks --region "$region" --stack-name "$P-base-$site" \
          --query "Stacks[0].Outputs[?OutputKey=='$rt'].OutputValue" --output text)
    echo "== $site $rt ($id)"
    aws ec2 search-transit-gateway-routes --region "$region" --transit-gateway-route-table-id "$id" \
      --filters Name=state,Values=active,blackhole \
      --query 'Routes[].[DestinationCidrBlock,Type,State,TransitGatewayAttachments[0].ResourceType]' --output table
  done
done
