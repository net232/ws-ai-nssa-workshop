#!/usr/bin/env python3
"""Offline check of a Cloud WAN core network policy (version 2021.12 subset).

It is a PARTIAL check. It catches the mistakes an AI most often makes when writing a policy from
memory: unknown keys, wrong condition types/operators, segment names that are
not defined, overlapping TGW ASNs. It is NOT a replacement for the service:
the real check is PutCoreNetworkPolicy + GetCoreNetworkPolicy (ChangeSetState,
PolicyErrors), see validate.sh --live.

The allowed keys come from "Core network policy version parameters in AWS Cloud
WAN": https://docs.aws.amazon.com/network-manager/latest/cloudwan/cloudwan-policies-json.html
Only the parts this workshop uses are listed; extend from the docs, not memory.
asn-ranges is treated as required, as in the minimal policy of the Cloud WAN
launch blog ("Required ASNs automatically assigned to CNEs"):
https://aws.amazon.com/blogs/networking-and-content-delivery/introducing-aws-cloud-wan-preview/

usage: check_policy.py POLICY.json [--tgw-asn 64600 --tgw-asn 64601]
"""
import argparse
import ipaddress
import json
import re
import sys

TOP = {"version", "core-network-configuration", "segments", "network-function-groups",
       "segment-actions", "attachment-policies", "attachment-routing-policy-rules",
       "routing-policies"}
VERSIONS = {"2021.12", "2025.11", "2026.10"}
CNC = {"vpn-ecmp-support", "dns-support", "security-group-referencing-support",
       "asn-ranges", "inside-cidr-blocks", "edge-locations"}
EDGE = {"location", "asn", "inside-cidr-blocks"}
SEGMENT = {"name", "description", "edge-locations", "isolate-attachments",
           "require-attachment-acceptance", "deny-filter", "allow-filter"}
RULE = {"rule-number", "description", "condition-logic", "conditions", "action"}
COND_TYPES = {"any", "resource-id", "region", "attachment-type", "account",
              "tag-name", "tag-value", "tag-exists"}
OPERATORS = {"equals", "not-equals", "contains", "begins-with"}
ATT_TYPES = {"vpc", "site-to-site-vpn", "connect", "transit-gateway-route-table"}
NEEDS_OPERATOR = {"resource-id", "region", "attachment-type", "account", "tag-value"}
ACTION = {"association-method", "segment", "tag-value-of-key", "require-acceptance",
          "add-to-network-function-group"}


def asn_ranges(policy):
    out = []
    for r in policy.get("core-network-configuration", {}).get("asn-ranges", []):
        lo, hi = (int(x) for x in str(r).split("-"))
        out.append((lo, hi))
    return out


def check(policy, tgw_asns):
    errs = []

    def unknown(where, obj, allowed):
        for k in obj:
            if k not in allowed:
                errs.append(f"{where}: unknown key '{k}'")

    unknown("top", policy, TOP)
    if policy.get("version") not in VERSIONS:
        errs.append(f"version: '{policy.get('version')}' not in {sorted(VERSIONS)}")

    cnc = policy.get("core-network-configuration")
    if not cnc:
        errs.append("core-network-configuration: required")
        cnc = {}
    unknown("core-network-configuration", cnc, CNC)
    edges = []
    for i, e in enumerate(cnc.get("edge-locations", [])):
        unknown(f"edge-locations[{i}]", e, EDGE)
        if not re.fullmatch(r"[a-z]{2}(-[a-z]+)+-\d", e.get("location", "")):
            errs.append(f"edge-locations[{i}].location: '{e.get('location')}' is not a Region code")
        edges.append(e.get("location"))
    if not edges:
        errs.append("core-network-configuration.edge-locations: at least one")
    if not cnc.get("asn-ranges"):
        errs.append("core-network-configuration.asn-ranges: required")
    for lo, hi in asn_ranges(policy):
        ok = (64512 <= lo <= hi <= 65534) or (4200000000 <= lo <= hi <= 4294967294)
        if not ok:
            errs.append(f"asn-ranges: {lo}-{hi} outside 64512-65534 / 4200000000-4294967294")
        for asn in tgw_asns:
            if lo <= asn <= hi:
                errs.append(f"asn-ranges: TGW ASN {asn} falls in {lo}-{hi}; peering would fail")
    for c in cnc.get("inside-cidr-blocks", []):
        ipaddress.ip_network(c)

    seg_names = []
    for i, s in enumerate(policy.get("segments", [])):
        unknown(f"segments[{i}]", s, SEGMENT)
        name = s.get("name", "")
        if not re.fullmatch(r"[A-Za-z0-9]+", name):
            errs.append(f"segments[{i}].name: '{name}' must be a-z, A-Z, 0-9 only")
        for loc in s.get("edge-locations", []):
            if loc not in edges:
                errs.append(f"segments[{i}].edge-locations: '{loc}' not in core edge-locations")
        if "deny-filter" in s and "allow-filter" in s:
            errs.append(f"segments[{i}]: allow-filter and deny-filter can't be used together")
        seg_names.append(name)
    if not seg_names:
        errs.append("segments: at least one segment is required")

    nums = set()
    for i, r in enumerate(policy.get("attachment-policies", [])):
        where = f"attachment-policies[{i}]"
        unknown(where, r, RULE)
        n = r.get("rule-number")
        if not isinstance(n, int) or not 1 <= n <= 65535:
            errs.append(f"{where}.rule-number: {n!r} must be 1-65535")
        if n in nums:
            errs.append(f"{where}.rule-number: {n} duplicated")
        nums.add(n)
        if "conditions" not in r:
            errs.append(f"{where}.conditions: required (use [] or a condition of type 'any')")
        conds = r.get("conditions", [])
        if len(conds) > 1 and r.get("condition-logic") not in ("and", "or"):
            errs.append(f"{where}.condition-logic: required ('and'|'or') with more than one condition")
        for j, c in enumerate(conds):
            t = c.get("type")
            if t not in COND_TYPES:
                errs.append(f"{where}.conditions[{j}].type: '{t}' unknown")
            if "operator" in c and c["operator"] not in OPERATORS:
                errs.append(f"{where}.conditions[{j}].operator: '{c['operator']}' unknown")
            if t in NEEDS_OPERATOR:
                if "operator" not in c:
                    errs.append(f"{where}.conditions[{j}]: '{t}' needs 'operator'")
                if "value" not in c:
                    errs.append(f"{where}.conditions[{j}]: '{t}' needs 'value'")
            if t == "attachment-type" and c.get("value") not in ATT_TYPES:
                errs.append(f"{where}.conditions[{j}].value: '{c.get('value')}' not an attachment type")
            if t in ("tag-value", "tag-name", "tag-exists") and not c.get("key"):
                errs.append(f"{where}.conditions[{j}]: '{t}' needs 'key'")
        a = r.get("action")
        if not a:
            errs.append(f"{where}.action: required and must not be empty")
            a = {}
        unknown(f"{where}.action", a, ACTION)
        m = a.get("association-method")
        if a and m is None and "add-to-network-function-group" not in a:
            errs.append(f"{where}.action: needs association-method (constant|tag) or add-to-network-function-group")
        if m == "constant" and a.get("segment") not in seg_names:
            errs.append(f"{where}.action.segment: '{a.get('segment')}' is not a defined segment")
        if m == "tag" and not a.get("tag-value-of-key"):
            errs.append(f"{where}.action: association-method 'tag' needs tag-value-of-key")
        if m not in (None, "constant", "tag"):
            errs.append(f"{where}.action.association-method: '{m}' must be constant|tag")
    return errs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("policy")
    ap.add_argument("--tgw-asn", type=int, action="append", default=[])
    args = ap.parse_args()
    with open(args.policy) as f:
        policy = json.load(f)
    errs = check(policy, args.tgw_asn)
    for e in errs:
        print(f"ERROR {e}")
    # Only the keys and rules listed above are checked; the service is the final judge.
    print("부분 검사 OK (서비스 검증은 validate.sh --live)" if not errs else f"{len(errs)} error(s)")
    sys.exit(1 if errs else 0)


if __name__ == "__main__":
    main()
