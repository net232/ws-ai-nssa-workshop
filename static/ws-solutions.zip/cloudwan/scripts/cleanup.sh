#!/usr/bin/env bash
# Delete every stack of the module, newest first. Core network edges are billed
# per hour, so run this right after the rehearsal.
set -uo pipefail
SEL=ap-northeast-2; TYO=ap-northeast-1; P=ws-ai-nssa-cwan

# Show which account and Region this will delete from; FORCE=1 skips the question.
ACCT="$(aws sts get-caller-identity --region "$SEL" --query Account --output text)"
echo "계정 $ACCT 의 ws-ai-nssa-cwan-* 리소스를 삭제합니다 (리전: $SEL, $TYO)."
if [[ "${FORCE:-0}" != 1 ]]; then
  read -r -p "맞으면 yes 를 입력하세요: " ok
  [[ "$ok" == yes ]] || { echo "중단했습니다."; exit 1; }
fi
del() { aws cloudformation delete-stack --region "$1" --stack-name "$2"; }
waitdel() { aws cloudformation wait stack-delete-complete --region "$1" --stack-name "$2"; }

del $SEL $P-attach-sel; del $TYO $P-attach-tyo
waitdel $SEL $P-attach-sel; waitdel $TYO $P-attach-tyo
del $SEL $P-core;      waitdel $SEL $P-core
del $SEL $P-routes-sel; del $TYO $P-routes-tyo
waitdel $SEL $P-routes-sel; waitdel $TYO $P-routes-tyo
del $SEL $P-peering;   waitdel $SEL $P-peering
del $SEL $P-base-sel; del $TYO $P-base-tyo
waitdel $SEL $P-base-sel; waitdel $TYO $P-base-tyo
echo "remaining:"
for r in $SEL $TYO; do
  aws cloudformation list-stacks --region "$r" --stack-status-filter CREATE_COMPLETE UPDATE_COMPLETE DELETE_FAILED \
    --query "StackSummaries[?starts_with(StackName,'$P')].[StackName,StackStatus]" --output text
done
