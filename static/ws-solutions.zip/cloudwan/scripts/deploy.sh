#!/usr/bin/env bash
# Optional rehearsal deploy of the whole module (Before -> After -> cut-over).
# Cost: each core network edge is billed per hour (2 edges here), plus hourly
# peering connections; see https://aws.amazon.com/cloud-wan/pricing/ .
# Run scripts/cleanup.sh as soon as the rehearsal ends.
#
# usage: deploy.sh before | after | precheck | cutover
#   precheck  checks that Cloud WAN is ready to carry the traffic (no changes)
#   cutover   runs precheck first, then deletes the TGW peering static routes and the peering
set -euo pipefail
cd "$(dirname "$0")/.."

SEL=ap-northeast-2
TYO=ap-northeast-1
NM=us-west-2          # Network Manager API endpoint (home Region)
P=ws-ai-nssa-cwan     # stack name prefix (workshop rule: ws-ai-nssa-)
TAGS=(Project=ws-ai-nssa)

out() { # out REGION STACK KEY
  aws cloudformation describe-stacks --region "$1" --stack-name "$2" \
    --query "Stacks[0].Outputs[?OutputKey=='$3'].OutputValue" --output text
}
deploy() { # deploy REGION STACK TEMPLATE [k=v ...]
  local region=$1 stack=$2 tpl=$3; shift 3
  local params=()
  (( $# )) && params=(--parameter-overrides "$@")
  aws cloudformation deploy --region "$region" --stack-name "$stack" \
    --template-file "$tpl" --no-fail-on-empty-changeset --tags "${TAGS[@]}" "${params[@]}"
}

# Background jobs: remember each PID and fail if any job failed.
PIDS=()
bg() { "$@" & PIDS+=("$!"); }
wait_all() {
  local rc=0 pid
  for pid in "${PIDS[@]}"; do wait "$pid" || rc=1; done
  PIDS=()
  if (( rc )); then echo "ERROR: a parallel deploy failed; see the stack events above" >&2; exit 1; fi
}

# There is no "aws ec2 wait" waiter for TGW attachments; poll the state.
wait_peering() { # wait_peering REGION ATTACHMENT_ID STATE
  local s=""
  for _ in $(seq 1 60); do
    s=$(aws ec2 describe-transit-gateway-peering-attachments --region "$1" \
          --transit-gateway-attachment-ids "$2" \
          --query 'TransitGatewayPeeringAttachments[0].State' --output text)
    [[ "$s" == "$3" ]] && return 0
    sleep 10
  done
  echo "timeout: $2 in $1 is $s, expected $3" >&2; return 1
}

before() {
  bg deploy $SEL $P-base-sel static/cfn/10-base-region.yaml SiteName=sel ProdVpcCidr=10.1.0.0/16  DevVpcCidr=10.2.0.0/16  TgwAsn=64600
  bg deploy $TYO $P-base-tyo static/cfn/10-base-region.yaml SiteName=tyo ProdVpcCidr=10.11.0.0/16 DevVpcCidr=10.12.0.0/16 TgwAsn=64601
  wait_all

  deploy $SEL $P-peering static/cfn/20-tgw-peering.yaml \
    TransitGatewayId="$(out $SEL $P-base-sel TransitGatewayId)" \
    PeerTransitGatewayId="$(out $TYO $P-base-tyo TransitGatewayId)" PeerRegion=$TYO
  att=$(out $SEL $P-peering PeeringAttachmentId)

  echo "accept $att in $TYO"
  wait_peering $TYO "$att" pendingAcceptance
  aws ec2 accept-transit-gateway-peering-attachment --region $TYO --transit-gateway-attachment-id "$att" >/dev/null
  wait_peering $SEL "$att" available

  bg deploy $SEL $P-routes-sel static/cfn/21-peering-routes.yaml PeeringAttachmentId="$att" \
    PeerRouteTableId="$(out $SEL $P-base-sel PeerRouteTableId)" \
    ProdRouteTableId="$(out $SEL $P-base-sel ProdRouteTableId)" \
    DevRouteTableId="$(out $SEL $P-base-sel DevRouteTableId)" \
    RemoteProdCidr=10.11.0.0/16 RemoteDevCidr=10.12.0.0/16
  bg deploy $TYO $P-routes-tyo static/cfn/21-peering-routes.yaml PeeringAttachmentId="$att" \
    PeerRouteTableId="$(out $TYO $P-base-tyo PeerRouteTableId)" \
    ProdRouteTableId="$(out $TYO $P-base-tyo ProdRouteTableId)" \
    DevRouteTableId="$(out $TYO $P-base-tyo DevRouteTableId)" \
    RemoteProdCidr=10.1.0.0/16 RemoteDevCidr=10.2.0.0/16
  wait_all
}

after() {
  # Stack Region for the core network: confirm in the rehearsal (page 5-4).
  deploy $SEL $P-core static/cfn/30-cloudwan-core.yaml
  core=$(out $SEL $P-core CoreNetworkId)
  local site region
  for site in sel tyo; do
    region=$SEL; [[ $site == tyo ]] && region=$TYO
    bg deploy $region $P-attach-$site static/cfn/40-cwan-tgw-peering.yaml SiteName=$site CoreNetworkId="$core" \
      TransitGatewayId="$(out $region $P-base-$site TransitGatewayId)" \
      ProdRouteTableId="$(out $region $P-base-$site ProdRouteTableId)" \
      DevRouteTableId="$(out $region $P-base-$site DevRouteTableId)"
  done
  wait_all
}

# Cloud WAN must already carry every remote CIDR before the static routes go:
#   1. 4 TGW route table attachments AVAILABLE, each in the segment of its tag
#   2. at each edge, the segment route table holds the other Region's CIDR
# Run before cutover; it changes nothing.
precheck() {
  local core gn fail=0
  core=$(out $SEL $P-core CoreNetworkId)
  gn=$(out $SEL $P-core GlobalNetworkId)

  echo "== 1. route table attachments"
  local rows
  rows=$(aws networkmanager list-attachments --region $NM --core-network-id "$core" \
           --attachment-type TRANSIT_GATEWAY_ROUTE_TABLE \
           --query 'Attachments[].[EdgeLocation,SegmentName,State]' --output text)
  echo "$rows"
  for want in "$SEL prod" "$SEL dev" "$TYO prod" "$TYO dev"; do
    if ! grep -qE "^${want% *}[[:space:]]+${want#* }[[:space:]]+AVAILABLE$" <<<"$rows"; then
      echo "NOT READY: no AVAILABLE attachment for $want" >&2; fail=1
    fi
  done

  echo "== 2. remote CIDRs in the Cloud WAN segment route tables"
  local edge seg cidr n
  for check in "$SEL prod 10.11.0.0/16" "$SEL dev 10.12.0.0/16" "$TYO prod 10.1.0.0/16" "$TYO dev 10.2.0.0/16"; do
    read -r edge seg cidr <<<"$check"
    n=$(aws networkmanager get-network-routes --region $NM --global-network-id "$gn" \
          --route-table-identifier "CoreNetworkSegmentEdge={CoreNetworkId=$core,SegmentName=$seg,EdgeLocation=$edge}" \
          --exact-cidr-matches "$cidr" --states ACTIVE \
          --query 'length(NetworkRoutes)' --output text)
    echo "$edge/$seg $cidr: $n active route(s)"
    [[ "$n" =~ ^[1-9] ]] || { echo "NOT READY: $cidr missing in $seg at $edge" >&2; fail=1; }
  done
  if (( fail )); then echo "precheck FAILED: do not cut over" >&2; exit 1; fi
  echo "precheck OK"
}

cutover() {
  precheck
  # Static routes over TGW peering win over propagated Cloud WAN routes;
  # deleting them moves inter-Region traffic onto Cloud WAN.
  aws cloudformation delete-stack --region $SEL --stack-name $P-routes-sel
  aws cloudformation delete-stack --region $TYO --stack-name $P-routes-tyo
  aws cloudformation wait stack-delete-complete --region $SEL --stack-name $P-routes-sel
  aws cloudformation wait stack-delete-complete --region $TYO --stack-name $P-routes-tyo

  echo "== after: remote prod CIDR in each prod TGW route table (expect propagated)"
  aws ec2 search-transit-gateway-routes --region $SEL \
    --transit-gateway-route-table-id "$(out $SEL $P-base-sel ProdRouteTableId)" \
    --filters Name=route-search.exact-match,Values=10.11.0.0/16 \
    --query 'Routes[].[DestinationCidrBlock,Type,State]' --output text
  aws ec2 search-transit-gateway-routes --region $TYO \
    --transit-gateway-route-table-id "$(out $TYO $P-base-tyo ProdRouteTableId)" \
    --filters Name=route-search.exact-match,Values=10.1.0.0/16 \
    --query 'Routes[].[DestinationCidrBlock,Type,State]' --output text

  aws cloudformation delete-stack --region $SEL --stack-name $P-peering
  aws cloudformation wait stack-delete-complete --region $SEL --stack-name $P-peering
}

case "${1:-}" in
  before|after|precheck|cutover) "$1" ;;
  *) echo "usage: $0 before | after | precheck | cutover" >&2; exit 2 ;;
esac
