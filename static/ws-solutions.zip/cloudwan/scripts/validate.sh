#!/usr/bin/env bash
# Offline checks for the Cloud WAN module (no AWS changes):
#   1. cfn-lint on every template
#   2. policy JSON parses and passes check_policy.py
#   3. the policy embedded in 30-cloudwan-core.yaml equals policy/core-network-policy.json
# --live CORE_NETWORK_ID [--keep] additionally uploads the policy as a new (not
# executed) policy version and passes only if ChangeSetState is READY_TO_EXECUTE
# and PolicyErrors is empty. The check version is deleted on exit
# (DeleteCoreNetworkPolicyVersion) unless --keep. Rehearsal accounts only.
set -euo pipefail
cd "$(dirname "$0")/.."

TGW_ASNS=(--tgw-asn 64600 --tgw-asn 64601)
NM_REGION=us-west-2   # Network Manager API endpoint (home Region) for all Regions

echo "== cfn-lint"
cfn-lint static/cfn/*.yaml
echo "OK"

echo "== policy"
python3 -m json.tool policy/core-network-policy.json >/dev/null
python3 scripts/check_policy.py policy/core-network-policy.json "${TGW_ASNS[@]}"

echo "== template policy == policy file"
uv run --quiet --with pyyaml python - <<'PY'
import json, yaml

class L(yaml.SafeLoader):
    pass
# accept CloudFormation short-form tags (!Ref, !Sub, ...) as plain values
L.add_multi_constructor("!", lambda loader, suffix, node: None)

tpl = yaml.load(open("static/cfn/30-cloudwan-core.yaml"), Loader=L)
embedded = tpl["Resources"]["CoreNetwork"]["Properties"]["PolicyDocument"]
filed = json.load(open("policy/core-network-policy.json"))
if embedded != filed:
    raise SystemExit("MISMATCH: static/cfn/30-cloudwan-core.yaml PolicyDocument != policy/core-network-policy.json")
print("OK")
PY

if [[ "${1:-}" == "--live" ]]; then
  CORE_NETWORK_ID="${2:?usage: validate.sh --live <core-network-id> [--keep]}"
  KEEP="${3:-}"
  echo "== live: PutCoreNetworkPolicy (creates a new policy version, does not execute it)"
  ver=$(aws networkmanager put-core-network-policy --region "$NM_REGION" \
          --core-network-id "$CORE_NETWORK_ID" \
          --policy-document file://policy/core-network-policy.json \
          --description "validate.sh check (not executed)" \
          --query 'CoreNetworkPolicy.PolicyVersionId' --output text)
  # The check version is never executed; delete it on exit unless --keep.
  # (A new version can make older not-executed versions OUT_OF_DATE; that is harmless.)
  if [[ "$KEEP" != "--keep" ]]; then
    trap 'aws networkmanager delete-core-network-policy-version --region "$NM_REGION" \
            --core-network-id "$CORE_NETWORK_ID" --policy-version-id "$ver" >/dev/null \
          && echo "deleted check policy version $ver"' EXIT
  fi
  state=PENDING_GENERATION
  for _ in $(seq 1 30); do
    state=$(aws networkmanager get-core-network-policy --region "$NM_REGION" \
              --core-network-id "$CORE_NETWORK_ID" --policy-version-id "$ver" \
              --query 'CoreNetworkPolicy.ChangeSetState' --output text)
    [[ "$state" != "PENDING_GENERATION" ]] && break
    sleep 10
  done
  # shellcheck disable=SC2016  # JMESPath literal, not shell
  errors=$(aws networkmanager get-core-network-policy --region "$NM_REGION" \
             --core-network-id "$CORE_NETWORK_ID" --policy-version-id "$ver" \
             --query 'length(CoreNetworkPolicy.PolicyErrors || `[]`)' --output text)
  echo "policy version $ver: ChangeSetState=$state, PolicyErrors=$errors"
  if [[ "$state" != "READY_TO_EXECUTE" || "$errors" != "0" ]]; then
    aws networkmanager get-core-network-policy --region "$NM_REGION" \
      --core-network-id "$CORE_NETWORK_ID" --policy-version-id "$ver" \
      --query 'CoreNetworkPolicy.PolicyErrors' --output table
    [[ "$state" == "PENDING_GENERATION" ]] && echo "FAIL: timed out waiting for change set generation" >&2
    echo "FAIL: live policy check" >&2
    exit 1
  fi
  echo "live policy check OK"
fi
