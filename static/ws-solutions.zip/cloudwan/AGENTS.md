# ws-cloudwan-migration — 워크숍 저장소 규칙 (예시 산출물)

"TGW에서 Cloud WAN으로" 워크숍을 Workshop Studio 형식으로 만드는 저장소입니다. 범위와 모듈 순서는 `storyboard.md`가 기준이며, 바꿀 때는 그 파일을 먼저 고칩니다.

## 구조

- `contentspec.yaml` — Workshop Studio 설정. 언어 `ko-KR`.
- `content/<NN-module>/index.ko.md` — 모듈 페이지. frontmatter `title`, `weight`(NN과 같은 순서).
- `static/images/` — 구성도. 원본 layout spec은 `static/images/src/`.
- `static/cfn/` — 참석자가 배포하는 템플릿. `policy/` — core network policy 원본 JSON.
- `scripts/` — `validate.sh`(오프라인 검증), `show-routes.sh`(증적), `cleanup.sh`.

## 환경

- 리전: 서울 `ap-northeast-2`, 도쿄 `ap-northeast-1`. **모든 aws 명령에 `--region`을 씁니다**(참석자 셸의 `AWS_REGION`은 Bedrock용 `us-east-1`).
- Network Manager API(`aws networkmanager ...`)는 홈 리전 엔드포인트를 쓰므로 `--region us-west-2`로 부릅니다.
- ASN: Cloud WAN `64512-64520`, TGW 서울 `64600`, 도쿄 `64601`.

## 작성 규칙

- 한국어 합니다체. 서비스·API·CLI·파라미터 이름은 원문 그대로.
- 모듈 페이지 구성: 목표 → 구성도 → 단계(명령 + 예상 출력) → **확인**(라우팅 테이블/상태 값) → 정리.
- 알림: `::alert[...]{type="info|warning"}`, 탭: `::::tabs` / `:::tab{label="..."}`, 펼침: `::::expand{header="..."}`.
- 명령은 복사해서 그대로 실행되게 씁니다. 자리표시자는 `<core-network-id>`처럼 꺾쇠로 표시하고 바로 위에서 값을 얻는 명령을 보여 줍니다.
- 비용이 나오는 단계 앞에는 `type="warning"` 알림으로 시간당 비용과 정리 방법을 씁니다.

## 검증

- 정책 키·CFN 속성은 AWS 문서로 확인한 것만 씁니다. 모르면 `TODO(확인 필요)`.
- 커밋 전에 `scripts/validate.sh`(cfn-lint, 정책 검사, 템플릿 안 정책 = `policy/` 원본) 통과.
- 페이지의 "예상 출력"은 리허설에서 실제로 받은 출력으로 바꿉니다. 받기 전에는 `<!-- 리허설 전 -->` 주석을 남깁니다.
