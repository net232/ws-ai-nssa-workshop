# solutions/cloudwan — Lab 5 정답 예시 (강사용)

"TGW에서 Cloud WAN으로" 워크숍의 모듈 2를 AI로 만든 결과물입니다. 참석자는 `~/ws-cloudwan-workshop`에서 직접 만들고, 이 폴더와 비교합니다.
폴더 구조는 참석자 저장소(`~/ws-cloudwan-workshop`)와 같습니다. 워크숍 환경에서는 `~/ws-solutions/cloudwan/`에 풀려 있고, 참석자는 5-2에서 `static/cfn/`과 `scripts/`를 복사합니다.

| 경로 | 내용 | Lab 5 단계 |
|---|---|---|
| `storyboard.md` | 워크숍 스토리보드 | 5-1 |
| `AGENTS.md` | 워크숍 저장소 규약 | 5-1 |
| `policy/core-network-policy.json` | core network policy (검증 통과본) | 5-2 |
| `policy/core-network-policy.ai-draft.json` | 문서 없이 쓴 AI 초안 (틀린 곳 6가지, 검사기 음성 대조용) | 5-2 |
| `static/cfn/10-base-region.yaml` | 리전 하나분 VPC 2개 + TGW + prod/dev/peer RT | 5-2 |
| `static/cfn/20-tgw-peering.yaml`, `static/cfn/21-peering-routes.yaml` | Before: TGW 간 peering과 정적 경로 | 5-2 |
| `static/cfn/30-cloudwan-core.yaml` | global network + core network (policy 내장) | 5-2 |
| `static/cfn/40-cwan-tgw-peering.yaml` | TGW ↔ core network peering, route table attachment | 5-2 |
| `scripts/check_policy.py` | 오프라인 policy 검사기 | 5-2 |
| `scripts/validate.sh` | cfn-lint + 정책 검사 + 템플릿/원본 일치 (`--live`는 선택) | 5-2 |
| `scripts/deploy.sh` | 리허설 배포 `before` / `after` / `precheck` / `cutover` (병렬 배포 실패 검사, cutover 전 Cloud WAN 경로 확인) | 5-4 |
| `scripts/show-routes.sh`, `scripts/cleanup.sh` | 증적 출력, 삭제 | 5-4 |
| `sample-module/index.ko.md` | 모듈 2 페이지 완성본 | 5-3 |

## 스택 (접두어 `ws-ai-nssa-cwan-`)

| 스택 | 리전 | 템플릿 |
|---|---|---|
| `ws-ai-nssa-cwan-base-sel` / `-base-tyo` | ap-northeast-2 / ap-northeast-1 | 10 |
| `ws-ai-nssa-cwan-peering` | ap-northeast-2 | 20 |
| `ws-ai-nssa-cwan-routes-sel` / `-routes-tyo` | ap-northeast-2 / ap-northeast-1 | 21 |
| `ws-ai-nssa-cwan-core` | ap-northeast-2 | 30 |
| `ws-ai-nssa-cwan-attach-sel` / `-attach-tyo` | ap-northeast-2 / ap-northeast-1 | 40 |

삭제 순서: attach-* → core → routes-* → peering → base-* (`scripts/cleanup.sh`).

태그: 스택은 `--tags Project=ws-ai-nssa`로 배포하고, 템플릿의 태그 가능한 리소스에도 `Project=ws-ai-nssa`를 붙였습니다.

## 검증 상태

- `scripts/validate.sh`: 통과 (cfn-lint 0건, 정책 부분 검사 OK, 템플릿 정책 = 원본). `--live`는 `READY_TO_EXECUTE`이고 `PolicyErrors`가 비었을 때만 성공, 검사용 policy version은 끝나면 삭제(`--keep`으로 유지).
- `check_policy.py`: 정답 OK, AI 초안 8건 실패, `asn-ranges` 누락·`operator` 누락·빈 `action`도 실패.
- `shellcheck scripts/*.sh`: 0건.
- **배포 검증 안 함.** 리허설에서 확인할 것: core 스택 배포 리전, core network 생성 시간, policy table association 필요 여부, peering `AVAILABLE` 전 attachment 생성 순서.
