# 스토리보드: TGW에서 Cloud WAN으로 — 무중단 마이그레이션 워크숍 (예시 산출물)

> Lab 5의 1단계에서 Claude가 plan mode로 만든 초안을 강사가 다듬은 결과입니다. 참석자 결과와 비교용입니다.

## 대상과 목표

- 대상: 고객사 네트워크 엔지니어, TGW 운영 경험 있음, Cloud WAN 처음.
- 끝나면 할 수 있는 일
  1. 리전마다 TGW를 둔 기존 구조에서 prod/dev 격리를 유지하는 방법과 그 한계를 설명한다.
  2. Cloud WAN core network policy(세그먼트, attachment policy)를 직접 쓴다.
  3. TGW peering + TGW route table attachment로 **기존 VPC를 건드리지 않고** Cloud WAN에 붙인다.
  4. 정적 경로를 지워 리전 간 트래픽을 Cloud WAN으로 옮기고, 라우팅 테이블로 확인한다.

## 모듈 (총 2시간 30분)

| # | 모듈 | 시간 | 학습 목표 | 핵심 확인 |
|---|---|---|---|---|
| 0 | 시작 환경 배포 (Before) | 20분 | 서울·도쿄 TGW, VPC 4개, TGW 간 peering 구조 이해 | `show-routes.sh`: prod RT에 원격 prod만 있음 |
| 1 | Cloud WAN core network 만들기 | 25분 | global network, core network, policy 구조 | policy version `EXECUTION_SUCCEEDED` |
| 2 | **TGW를 Cloud WAN에 연결** (이 모듈을 Lab 5에서 작성) | 30분 | TGW peering, route table attachment, 태그 기반 세그먼트 매핑 | attachment `SegmentName` = prod/dev |
| 3 | 트래픽 전환 (cut-over) | 20분 | 정적 경로 우선순위, 전환 순서 | 원격 CIDR의 경로 유형이 static → propagated로 바뀜 |
| 4 | 격리 검증과 롤백 | 20분 | dev ↔ prod 차단 확인, 롤백 절차 | dev RT에 prod CIDR 없음 |
| 5 | 정리 | 10분 | 비용이 나오는 리소스 삭제 순서 | 스택 0개 |

## 시나리오 문장

"서울과 도쿄에 각각 TGW를 두고 TGW peering으로 리전을 이어 왔습니다. 리전이 늘 때마다 peering과 정적 경로가 늘고, prod/dev 격리를 라우팅 테이블마다 손으로 지켜야 합니다. 이제 Cloud WAN 세그먼트로 이 일을 정책 한 장에 모읍니다."

## 결정 사항 (강사 승인)

- 리전: `ap-northeast-2`, `ap-northeast-1`. ASN: Cloud WAN `64512-64520`, TGW `64600`/`64601`(겹치면 peering 불가).
- VPC를 Cloud WAN에 직접 붙이는 방법은 다음 워크숍에서 다룹니다(이번은 TGW 유지형 마이그레이션).
- 연결 확인은 라우팅 테이블로 합니다(EC2 없이 비용·시간 절약). ping 확인은 선택 과제.

## 열린 질문 (리허설에서 확인)

- core network 스택을 어느 리전에서 배포할지, 생성에 실제로 몇 분 걸리는지.
- TGW 측 policy table association이 CloudFormation에서 꼭 필요한지.
