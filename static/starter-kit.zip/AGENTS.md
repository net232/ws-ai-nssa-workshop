# <프로젝트 이름> — 신규 기능 테스트 / 워크숍 저장소

<한 줄 설명: 무엇을 테스트하거나 만드는지. 예) NLB mutual TLS 동작 검증과 워크숍 모듈 초안>

## 환경

- 실습 리전: `ap-northeast-2`. **aws CLI·CloudFormation 명령에는 항상 `--region ap-northeast-2`를 붙입니다.**
  - 이유: Claude Code가 Bedrock 호출용으로 `AWS_REGION=us-east-1`을 쓰고, 이 값이 Bash로 실행되는 aws CLI에도 그대로 상속됩니다. 리전을 빼면 리소스가 us-east-1에 만들어집니다.
- AWS 프로필: `<profile>` (없으면 기본 자격 증명). 프로덕션·고객 계정에서는 실행하지 않습니다.
- 모든 리소스에 태그 `Project=ws-ai-nssa`, `Owner=<이름>`을 붙입니다. CloudFormation은 `--tags`로 스택에 붙입니다.
- 스택 이름 접두어: `ws-ai-nssa-`.

## 작업 규칙

- 새 기능의 동작·파라미터·CFN 속성은 **AWS 문서로 확인한 것만** 씁니다(MCP `aws-knowledge`). 확인하지 못한 것은 `TODO(확인 필요)`로 남깁니다.
- 문서·계획서·워크숍 페이지에는 근거 문서 URL을 적습니다.
- 큰 작업은 먼저 계획(plan mode)을 보여 주고 승인받은 뒤 진행합니다.
- 리소스 삭제(`delete-*`, `delete-stack`, `terminate-*`)는 실행 전에 대상 목록을 보여 주고 확인받습니다.
- 비용이 큰 리소스(Cloud WAN core network, NAT Gateway, 다수 EC2)는 만들기 전에 시간당 비용을 알려 줍니다.

## 검증

- CloudFormation: `cfn-lint <template>` 통과 후 배포. 배포 전 `aws cloudformation validate-template --region ap-northeast-2`.
- 셸 스크립트: `bash -n`, 가능하면 `shellcheck`.
- 테스트 결과는 기대값/실제값/명령 출력(증적)을 `results.md`에 남깁니다. "성공했다"는 말만으로 끝내지 않습니다.

## 폴더

- 루트: `research.md`(조사) · `test-plan.md`(계획) · `results.md`(결과와 증적) · `rca.md`(장애 분석) · `review.md`(리뷰)
- `infra/` CloudFormation · `scripts/` 인증서·테스트·장애 주입 스크립트 · `notes/` 기타 조사 메모
