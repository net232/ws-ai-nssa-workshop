# Starter kit

워크숍 실습 폴더에 복사해 쓰는 Claude Code 설정 예시입니다.

```bash
mkdir -p ~/ws-lab && cp -r ./. ~/ws-lab/   # 숨김 파일(.claude, .mcp.json) 포함
cd ~/ws-lab && git init
```

| 파일 | 역할 |
|---|---|
| `CLAUDE.md` | `@AGENTS.md` 한 줄. Claude Code가 자동으로 읽는 진입점 |
| `AGENTS.md` | 프로젝트 규칙(리전·태그·검증·삭제 규칙). Codex 같은 다른 에이전트와 공유 |
| `.claude/settings.json` | 권한(allow/ask/deny)과 PreToolUse hook 등록 |
| `.claude/hooks/guard-aws.sh` | 리전 없는 aws 명령 차단, 파괴적 명령 재확인(`jq` 필요) |
| `.claude/agents/net-reviewer.md` | 독립 리뷰용 subagent(읽기 전용) |
| `.claude/skills/net-test-plan/SKILL.md` | 신규 기능 테스트 계획서 skill (`/net-test-plan`) |
| `.mcp.json` | AWS Knowledge MCP(원격), AWS IaC MCP(`uvx`) |

`AGENTS.md`의 `<...>` 부분은 자기 환경에 맞게 고칩니다.
