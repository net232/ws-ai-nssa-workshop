#!/usr/bin/env bash
# PreToolUse hook (matcher: Bash) — aws CLI 명령을 실행 전에 점검합니다.
#  1) 리전 없는 aws 명령은 막습니다(exit 2). Claude Code의 AWS_REGION(us-east-1, Bedrock용)이
#     aws CLI에 상속되어 리소스가 엉뚱한 리전에 생기는 것을 막기 위해서입니다.
#  2) 파괴적 명령(delete/terminate/...)은 사용자에게 다시 묻습니다(permissionDecision: ask).
# 입력: stdin JSON {"tool_name":"Bash","tool_input":{"command":"..."}, ...}
set -euo pipefail

LAB_REGION="${LAB_REGION:-ap-northeast-2}"
input="$(cat)"
cmd="$(jq -r '.tool_input.command // empty' <<<"$input")"
[[ -z "$cmd" ]] && exit 0

# 줄 끝의 \ (줄 연속)를 먼저 합친 뒤, ; && || | 줄바꿈 단위로 나눠 aws 호출만 살펴봅니다.
# 한계: 스크립트 파일 안의 명령(bash cleanup.sh)이나 eval·변수로 만든 명령은 보지 못합니다.
joined="$(sed -e ':a' -e '/\\$/N; s/\\\n/ /; ta' <<<"$cmd")"
segments="$(sed -E 's/(\&\&|\|\||;|\|)/\n/g' <<<"$joined")"

ask_reason=""
while IFS= read -r seg; do
  seg="${seg#"${seg%%[![:space:]]*}"}"   # 앞 공백 제거
  # 앞에 붙은 sudo, env, VAR=값 을 걷어 냅니다(예: AWS_PROFILE=lab aws ...).
  while [[ "$seg" =~ ^(sudo|env|[A-Za-z_][A-Za-z0-9_]*=[^[:space:]]*)[[:space:]]+(.*)$ ]]; do
    seg="${BASH_REMATCH[2]}"
  done
  [[ "$seg" =~ ^aws[[:space:]] ]] || continue

  # 전역 서비스와 도움말·설정 명령은 리전 검사에서 뺍니다.
  if ! [[ "$seg" =~ [[:space:]](iam|sts|organizations|route53|configure|help)([[:space:]]|$) ]] \
     && ! [[ "$seg" =~ --region([[:space:]]|=) ]]; then
    echo "리전이 없는 aws 명령은 막았습니다: '$seg'. --region $LAB_REGION 을 붙여 다시 실행하세요(AWS_REGION은 Bedrock용 us-east-1입니다)." >&2
    exit 2
  fi

  if [[ "$seg" =~ [[:space:]](delete-|terminate-|deregister-|revoke-|disassociate-|detach-|reject-)[a-z-]+ ]] \
     || [[ "$seg" =~ [[:space:]]s3[[:space:]]+(rm|rb)([[:space:]]|$) ]]; then
    ask_reason="파괴적 aws 명령입니다: '$seg'. 대상 리소스와 계정·리전을 확인하세요."
  fi
done <<<"$segments"

if [[ -n "$ask_reason" ]]; then
  jq -n --arg r "$ask_reason" '{hookSpecificOutput:{hookEventName:"PreToolUse",permissionDecision:"ask",permissionDecisionReason:$r}}'
fi
exit 0
